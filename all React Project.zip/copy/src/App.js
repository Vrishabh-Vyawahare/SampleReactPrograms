import {Fragment} from'react'
import Calculator from './components/Calculator';
// import Header from './components/Header.js'
// import Welcome from './components/Welcome.js'
function App() {
  return (
    <Fragment>
      {/* <Header brand="My  React App"/>
      <Welcome /> */}
      <Calculator />
    </Fragment>
  );
}

export default App;