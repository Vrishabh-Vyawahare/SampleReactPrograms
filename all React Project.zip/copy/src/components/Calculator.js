import {Component} from 'react'
class Calculator extends Component {
    constructor() {
      super();
      this.state = {
          num1:0,
          num2:0,
          

      };
    }
    update=event=>{
        this.setState({num1:event.target.value})   
    }
    update2=event=>{
      this.setState({num2:event.target.value})
    }
   
   
    
    render() {
      let sum=(this.state.num1) + (this.state.num2);
      let diff=this.state.num1-this.state.num2;
      let mul=this.state.num1*this.state.num2;
      let div=this.state.num1/this.state.num2;
      let rem=this.state.num1%this.state.num2;
      return (
        <div className='container-fluid p-4'>
          <form>
              <div>
                <div>
                  <input type="number" name="num1" value={this.state.num1}
                  onChange={this.update} className='form-control' />
                  </div>
              <div>
                  <input type="number" name="num2" value={this.state.num2}
                  onChange={this.update2} className='form-control' />
                  </div>
                 
                 <div>
                   <label>Addition=</label>
                  {sum}
                  </div>
                  <div>
                  <label>Substraction=</label>
                  {diff}
                  </div>
                  <div>
                  <label>Multiplication=</label>
                  {mul}
                  </div>
                  <div>
                  <label>Division=</label>
                  {div}
                  </div>
                  <div>
                  <label>Remainder=</label>
                  {rem}
                  </div>
              </div>
          </form>
        </div>
      );
    }
  }
  export default Calculator;