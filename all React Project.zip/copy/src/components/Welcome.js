import {Component} from 'react'
class Welcome extends Component {
    constructor() {
      super();
      this.state = {username:"Vrishabh"};
    }
    update=event=>{
        let modifiedvalue=event.target.value;
        this.setState({username:modifiedvalue});
    }
    render() {
      return (
        <div className='container-fluid p-4'>
          <h4>Hello {this.state.username}! You are Welcome</h4>
          <form className='col-sm-4 mt-2'>
              <label>Name:
                  <input type="text" value={this.state.username} className="form-control" onChange={this.update}/>
              </label>
          </form>
        </div>
      );
    }
  }
  export default Welcome;