//-----------------------------------------for...of loop( iterates over values)-------------------------------
let name="Vrishabh";

for(let letter of name){
    console.log(letter);

}

let scores = [80, 90, 70];

for (let score of scores) {
    console.log(score);
}
//-----------------------------------------for...in loop( iterates over keys)--------------------------------

let players = ['rohit','jaiswal','virat'];

for (let name in players) {
    console.log(players[name]);
}
//-----------------------------------------forEach()-----------------------------------------------------------

let captain=[
{
    team:'IND',
    captainname:'Rohit'
},
{
team:'AUS',
captainname:'pat Cummins'
}]
 captain.forEach((val,ind)=>{
    console.log(val.team);
 })