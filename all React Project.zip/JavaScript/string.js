let stringOne="vrishabh vyawahare";

console.log(stringOne.toUpperCase());  //VRISHABH VYAWAHARE
console.log(stringOne.toLowerCase());  //vrishabh vyawahare
console.log(stringOne.charAt(2));      //i
console.log(stringOne.substring(0,5));  //vrish
console.log(stringOne.includes('abh'));  //true

console.log(stringOne.slice(-3,17))   //ar
console.log(stringOne.trim());     //vrishabh vyawahare
console.log(stringOne.split(" "))   //[ 'vrishabh', 'vyawahare' ]