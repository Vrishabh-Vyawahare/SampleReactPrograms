// console.log(this);    //{}
// const object={
//     name:'vrishabh',
//     id:2101434,
//     greeting:function(){
//         console.log(this.name)     //vrishabh
//         console.log(this)}
// }
// object.greeting();
// console.log(this.name);    //undefined


function add(a,b) {
    return a + b;
}

console.log(window.add);


