let score=[12,34,56,78,90]

let user={
    username:'Vrishabh',
    userid:2101434
}
//function created using Object.prototype is present in object and array
Object.prototype.printMe=()=>{
 console.log('function created using Object.prototype is present in object and array')
}

user.printMe()  
score.printMe()

//function created using Array.prototype is present ONLY in array ano NOT in object.
Array.prototype.print=()=>{
    console.log('function created using Array.prototype is present ONLY in array ano NOT in object')
}
score.print()
// user.print() //function created using Array.prototype is present ONLY in array ano NOT in object.

