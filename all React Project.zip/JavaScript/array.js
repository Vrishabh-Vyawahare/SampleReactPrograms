var a = [1,2,3,4,5,6]
var b = [1,2,3,4,5,6,7,8,9,10]
var c =10;
var d =100;
var e =1000;
console.log(a);
console.log(a.slice(1,4));
console.log(a.slice(-4,6));   // start count from reverse for negative value.

console.log(a.splice(1,4));   // return removed 4 item from array position 1. original array is changed.
console.log(a);


console.log(b);
b.splice(3,4,15);   // remove 4 element from 3rd index and add 15 after removal of elements.
console.log(b);

console.log(b.splice(3,5))

console.log(Array.of(c,d,e)); // return new array from set of elements.

