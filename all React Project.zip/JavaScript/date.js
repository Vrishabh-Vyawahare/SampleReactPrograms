const d = new Date();
console.log(d);    // Date and time in string format

console.log(d.toDateString());  //Tue Jan 16 2024
console.log(d.toString());      //Tue Jan 16 2024 11:11:56 GMT+0530 (India Standard Time)
console.log(d.toLocaleDateString());  //16/1/2024
console.log(d.toLocaleTimeString());   //11:31:02 am
console.log(d.toLocaleString());     //16/1/2024, 11:31:02 am

let ms = Date.now();    // static method of the Date object that returns the number of milliseconds since January 1, 1970.
console.log(ms); 


