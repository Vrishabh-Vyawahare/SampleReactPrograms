let promise = new Promise(function(resolve, reject) {
    setTimeout(
        ()=>{
            let error=false;
            if(!error)
            {
                  resolve({username:'vrishabh',id:2101434})

            }
            else
            {
                reject("ERROR FOUND")
            }
        },1000
    )
    
  });

  promise.then((value)=>
      { 
          console.log(value);
          return value.username
      })
    .then((value)=>
    { 
        console.log(value);
    })
  .catch((err)=>console.log(err))

  //-----------------------------------------------------Using Async-Await------------------------------------------------
//  async function consumePromise(){
//     try
//     {
//     let response=await promise;
//     console.log(response.username);
//     }
//     catch(err){
//     console.log(err)
//     }
//  }
//  consumePromise();