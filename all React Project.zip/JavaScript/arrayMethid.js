//................................map()....................................................................
const numbers = [1, 2, 3, 4, 5];
const multiply = numbers.map((num)=>{
  return num *10 ;
});
console.log(multiply);

//.............................filter().......................................................................
const num = [1, 2, 3, 4, 5];
const smallnum = numbers.filter((n)=>n>3);
console.log(smallnum);

//..................................reduce()..................................................................
const price = [100,200,300,400,500];
const totalPrice=price.reduce((preVal,curVal)=>preVal+curVal,0)
console.log(totalPrice);




