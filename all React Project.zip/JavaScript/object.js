const mysym=Symbol("mykey");      //declare symbol
const emp={
    "name":'Vrishabh',
    "emp id":2101434,
    [mysym]:"myval"     //declaring symbol key in square bracket.
}

emp.greeting=function(){console.log("Hello World");}    //add function js object.
console.log(emp.name);
console.log(emp["emp id"]);
console.log(emp.greeting());
console.log(emp[mysym]);   //access symbol 

emp.name="Rahul"       //reassigning value for name key
console.log(emp.name);
Object.freeze(emp);    //freeze properties of object
emp.name="Vrishabh"    //cannot assigned new value as object is freezed.
console.log(emp.name);      



