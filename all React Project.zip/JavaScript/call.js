function box(height, width) {
    this.height = height;
    this.width = width;
  }
  
  function boxDetails(height, width, color) {
    box.call(this, height, width);
    this.color = color;
  }
  
  let boxInfo = new boxDetails(200,100,'red');
  
  console.log(boxInfo);