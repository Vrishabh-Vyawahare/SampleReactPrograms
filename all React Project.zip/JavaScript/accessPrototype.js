let personInfo={
    name:'Vrishabh',
    phone:7774947076
}

let companyDetails={
    companyName:'Cognizant',
    compnayid:2101434
}

console.log(personInfo.name);
personInfo.__proto__=companyDetails;
console.log(personInfo.companyName);

let family= Object.create(personInfo,{familyName:{value:'Vyawahare'},location:{value:'Pune'}});
console.log(family.phone);

Object.setPrototypeOf(family, companyDetails);
console.log(family.companyName)




