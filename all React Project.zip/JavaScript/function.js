// function add(){
// return num1 * num1;// if return is not used then we cannot store it into result variable.then result will be undefined.
// }

// const result=add();
// console.log(result);

function getValue(...num){      //rest operator used 
    return num;
}
console.log(getValue(20,3,40,30));

const store =[1,2,3,4,5]
function getValueFromStore(array){       
    console.log(`value is  ${array[3]}`)
}
getValueFromStore(store);       //argument is array

const objectStore ={username:"vrishabh",userid:20}
function getValueFromObjectStore(obj){       
  console.log(`user name is ${obj.username}`)
}
getValueFromObjectStore(objectStore); //argument is object

