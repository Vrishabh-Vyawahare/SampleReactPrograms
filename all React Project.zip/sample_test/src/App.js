import React, { useState } from 'react'
import {data} from './data.js'

const App = () => {
  const [country, setCountry] = useState("");
  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [stateList, setStateList] = useState([]);
  const [cityList, setCityList] = useState([]);

  const handleCountryChange = (event) => {
    setCountry(event.target.value);
    const filteredStates = data.find((item) => item.country === event.target.value).states;
    setStateList(filteredStates);
    setCity("");
  };

  const handleStateChange = (event) => {
    setState(event.target.value);
    const filteredCities = stateList.find((item) => item.state === event.target.value).cities;
    setCityList(filteredCities);
  };
  const handleCityChange = (event) => {
    setCity(event.target.value);
  };

  return (
    <div>
      <label>Country : </label>
      <select onChange={handleCountryChange}>
        <option value="">Select Country</option>
        {data.map((item) => (
          <option key={item.country} value={item.country}>
            {item.country}
          </option>
        ))}
      </select><br /><br />

      <label>State : </label>
      <select onChange={handleStateChange}>
        <option value="">Select State</option>
        {stateList.map((item) => (
          <option key={item.state} value={item.state}>
            {item.state}
          </option>
        ))}
      </select><br /><br />

      <label>City : </label>
      <select onChange={handleCityChange}>
        <option value="">Select City</option>
        {cityList.map((item) => (
          <option key={item.name} value={item.name}>
            {item.name}
          </option>
        ))}
      </select>
    </div>
  );
};


export default App;