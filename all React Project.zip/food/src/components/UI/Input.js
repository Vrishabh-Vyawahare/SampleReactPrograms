import styles from './Input.module.css'
function Input(props){
    return(
    <div className={styles.input}>
    <label className={styles.label} >
      {props.label}
    </label>
    <input className={styles.input.input} {...props.input}/>
    </div>
    )
}
export default Input;