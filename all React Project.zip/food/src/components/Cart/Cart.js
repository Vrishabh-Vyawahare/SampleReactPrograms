import styles from './Cart.module.css';
import Modal from '../UI/Modal.js';
const Cart=(props)=>{
    const CartItem= (<ul className={styles['cart-items']}>
    {   [
            {   id:'1',
                name:"Chiken Curry",
                Amount:2,
                price:200
            }
        ].map(
              (item)=>
              <li>{item.name}</li>
              )
    }
</ul>
  );
  
    return(
    <Modal closeCart={props.closeCart}>
        {CartItem}
      <div className={styles.total}>
       <span>Total Amount</span>
       <span>400</span>
      </div>
      <div className={styles.actions}>
        <button className={styles['button--alt']} onClick={props.closeCart}>Close</button>
        <button className={styles.button}>Order</button>
      </div> 
      </Modal>
    );
};
export default Cart;
