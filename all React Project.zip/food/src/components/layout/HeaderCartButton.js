import styles from './HCButton.module.css'
import { useContext } from 'react';
import CartContext from '../../store/CartContext';
import Icon from '../Cart/Icon.js'
function HeaderCartButton(props){
    const Cartctx=useContext(CartContext);
    const numberOfCartItem=Cartctx.items.reduce((crtNum,item)=>{return crtNum+item.Amount;},0);
    return(
     <button className={styles.button} onClick={props.onClick}>
    <span className={styles.icon}>
      <Icon /> 
    </span>
    <span>
        Your Cart
    </span>
    <span className={styles.badge}>
        {numberOfCartItem}
    </span>
</button>
    )
}
export default HeaderCartButton;