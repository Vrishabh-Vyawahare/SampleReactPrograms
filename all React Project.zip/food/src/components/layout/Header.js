import HeaderCartButton from './HeaderCartButton.js';
import styles from './Header.module.css';
function Header(props){
    return(
    <div>
    <header className={styles.head}>
        <h1>MEAL FOOD</h1>
      <HeaderCartButton onClick={props.Show}/>
    </header>
    <div className={styles.image}>
        <img src='https://previews.123rf.com/images/rawpixel/rawpixel1510/rawpixel151025608/47062607-food-table-celebration-delicious-party-meal-concept.jpg' alt="Meal Food table"></img>
    </div>
    </div>
    );

};
export default Header;