import style from './Item.module.css';
import ItemForm from './Itemform';
function MItem(p){
    return(
        <li  className={style.meal}>
            <div>
                <h3  className={style.meal.h3}>{p.name}</h3>
                <div className={style.price}>{p.price}</div>
            </div>
            <div><ItemForm /></div>
        </li>
    )
}
export default MItem;