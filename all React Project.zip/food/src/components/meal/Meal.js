import { Fragment } from "react";
import MealAvailable from "./MealAvailable";
import MealSummary from "./MealSummary";
function Meal(){
    return(
        <Fragment>
            <section>
            <MealSummary />
         <MealAvailable />
            </section>
        
        </Fragment>
    )
}
export default Meal;