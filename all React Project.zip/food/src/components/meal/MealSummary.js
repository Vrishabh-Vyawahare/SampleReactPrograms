import { Fragment } from "react"
import styles from './Meal.module.css'

function MealSummary(){
    return(
    <Fragment>
<section className={styles.summary} >
    <h1>Order Meal Food Online And Enjoy !</h1>
    <p>
        Here,below is the list of delicious meals food .You can order Meal food online and taste it .
    </p>
</section>
    </Fragment>

    )
}
export default MealSummary;