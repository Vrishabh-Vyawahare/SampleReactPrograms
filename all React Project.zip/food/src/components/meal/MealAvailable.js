import styles from './MealAvailable.module.css'
import MItem from '../meal/item/MItem.js';
import Card from '../UI/Card.js';
function MealAvailable(){
    const MealItem=[
        {
            id:1,
            name:'Chiken Curry',
            Amount:200
        },
        {
            id:2,
            name:'Fish Curry',
            Amount:170
        },
        {
            id:3,
            name:'Chiken Fry',
            Amount:180
        },
        {
            id:4,
            name:'Fish Fry',
            Amount:150
        },
        {
            id:5,
            name:'Anda Masala',
            Amount:120
        }
    ]
    const MealItemList=MealItem.map(item=> 
    <MItem 
         key={item.id}
         name={item.name} 
         price={item.Amount} 
    />);
    return(
    <section className={styles.meals}>
     <ul>
         <Card>
        {MealItemList}
        </Card>
        </ul>
    </section>
      
    

    )
}
export default MealAvailable;