import CartContext from './CartContext.js';

const CartProvider=(props)=>{
    const addItemToCart=item=>{}
    const removeItemToCart=key=>{}
   const cartContext={
    items:[],
    totalAmount:0,
    addItem :addItemToCart,
    removeItem : removeItemToCart
   }
   
    return(
    <CartContext.Provider value={cartContext}>
     {props.children}
    </CartContext.Provider>
    )
}
export default CartProvider;