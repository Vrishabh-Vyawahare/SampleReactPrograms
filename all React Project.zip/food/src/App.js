import Header from './components/layout/Header.js';
import {useState} from 'react';
import Meal from './components/meal/Meal.js';
import Cart from './components/Cart/Cart.js';
import CartProvider from './store/CartContext';
function App() {
  const[cartShow,setCartShow]=useState(false);
  const showCart=()=>{
    setCartShow(true);
  }
  const HideCart=()=>{
    setCartShow(false);
  }

  return (
  <CartProvider>
  <Header Show={showCart}/>
  <Meal />
  {cartShow && <Cart closeCart={HideCart}/>}
  </CartProvider>
  );
}
export default App;
