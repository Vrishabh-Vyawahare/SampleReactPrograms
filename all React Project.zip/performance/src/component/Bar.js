import React, { useState } from 'react';
import {FaBars}from "react-icons/fa";
import { NavLink } from 'react-router-dom';
import MenuItem from './MenuItem.js'
const Bar = ({children}) => {
    const[isOpen ,setIsOpen] = useState(false);
    const toggle = () => setIsOpen (!isOpen);
    
    return (
        <div className="container">
            <div style={{width: isOpen ? "200px" : "70px"}} className="sidebar">
            <div className="top_section">
                  
                     
                <nav style={{marginLeft: isOpen ? "70px" : "0px"}} className="bars">
                   <FaBars onClick={toggle}/>
                </nav>
                   
            </div>
               {
                    MenuItem.map((item, index)=>(
                        <NavLink to={item.path} key={index} className="link" activeclassname="active">
                           <div className="icon">{item.icon}</div>
                           <div style={{display: isOpen ? "block" : "none"}} className="link_text"><b>{item.name}</b></div>
                        </NavLink>
                    ))
               }
            </div>
           <main>{children}</main>
        </div>
    );
};

export default Bar;