import React, { useState } from 'react';
import DateTimeRangePicker from '@wojtekmaj/react-datetimerange-picker';
function DateTime() {
  const [value, onChange] = useState(null, null);
  const [minDate, setMinDate] = useState(new Date(2022,8,15))
  const [maxDate, setMaxDate] = useState(new Date(2022,8,25))

  return (
    <div>
      <DateTimeRangePicker
      minDate={minDate} 
      maxDate={maxDate}
       onChange={onChange}
       value={value} 
       format={'dd-MM-yyyy HH:mm'} 
       disableClock={'true'} 
       rangeDivider={'To'}
       />
    </div>
  );
}
export default DateTime;