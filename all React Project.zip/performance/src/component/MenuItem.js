import {FaHome,FaInternetExplorer}from "react-icons/fa";
import {IoMdStats}from "react-icons/io";
import {AiFillSetting}from "react-icons/ai";

const MenuItem=[
    {
        path:"/",
        name:"Home",
        icon:<FaHome/>
    },
    {
        path:"/statistics",
        name:"Statistics",
        icon:<IoMdStats/>
    },
    {
        path:"/explore",
        name:"Explore",
        icon:<FaInternetExplorer/>
    },
    {
        path:"/setting",
        name:"Setting",
        icon:<AiFillSetting/>
    }
]
export default MenuItem;