import React from 'react'

export default function Setting() {
  return (
    <div style={{paddingTop:'45px'}}><h1>Setting</h1></div>
  )
}