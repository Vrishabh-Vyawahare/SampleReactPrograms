import React from 'react'

export default function Explore() {
  return (
    <div style={{paddingTop:'45px'}}>
      <h1>Explore</h1></div>
  )
}