import React from 'react'

export default function Statistics() {
  return (
    <div style={{paddingTop:'45px'}}><h1>Statistics</h1></div>
  )
}