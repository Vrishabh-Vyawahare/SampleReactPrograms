import React from 'react'
export default function Home() {
  return (
    <div style={{paddingTop:'45px'}}>
      <h1>Home</h1>
      <p>Rohit Gurunath Sharma (born 30 April 1987) is an Indian international cricketer who is the current captain of the Indian national cricket team. In the Indian Premier League he captains Mumbai Indians and is a right-handed opening batsman, and an occasional right-arm off break bowler. He plays for Mumbai in domestic cricket. In the IPL, the Mumbai Indians have won the tournament a record five times under his leadership.
      </p>
      
      </div>
  )
}