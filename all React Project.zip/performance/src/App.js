import {BrowserRouter,Routes,Route,} from "react-router-dom";
import Bar from './component/Bar';
import Explore from "./pages/Explore";
import Home from "./pages/Home";
import Setting from "./pages/Setting";
import Statistics from "./pages/Statistics";
import User from'./component/User'
import DateTime from'./component/DateTime'

import './App.css';

function App() {
  return (
 <>
    <div className="Navbar">
    <nav className='DateInput'>
       <DateTime />
       </nav>
      

      <nav className='User'>
        <User />
      </nav>
      
    </div>
    
    <BrowserRouter>

       <Bar>
       

         <Routes>

          <Route  exact path="/" element={<Home />}/>
          <Route path="/explore" element={<Explore />} />
          <Route path="/statistics" element={<Statistics />}/>
          <Route path="/setting" element={<Setting />} />

         </Routes>
        

      </Bar>
     
      

    </BrowserRouter>
  
   
  </> 
  
  );
}

export default App;