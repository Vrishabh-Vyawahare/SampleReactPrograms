import React from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import 'chartjs-adapter-date-fns';
import 'chartjs-adapter-luxon';
import { minutesToHours } from 'date-fns';
const Linechart = () => {
    const data={
        datasets:[
            {
                label:"RDIN124525654",
                borderColor:"grey",
                borderWidth:2,
                fill:false,
                //backgroundColor:"Pink",
                data:[
               { x:new Date ('2022-08-01T15:00:00'),y:34},
               { x:new Date ('2022-08-01T15:01:00'),y:35},
               { x:new Date ('2022-08-01T15:02:00'),y:40},
               { x:new Date ('2022-08-01T15:03:00'),y:36},
               { x:new Date ('2022-08-01T15:04:00'),y:35},
               { x:new Date ('2022-08-01T15:05:00'),y:50},
               { x:new Date ('2022-08-01T15:06:00'),y:40},
               { x:new Date ('2022-08-01T15:07:00'),y:35},
               { x:new Date ('2022-08-01T15:08:00'),y:50},
               { x:new Date ('2022-08-01T15:09:00'),y:32},
               { x:new Date ('2022-08-01T15:10:00'),y:30},
               { x:new Date ('2022-08-01T15:11:00'),y:48},
               { x:new Date ('2022-08-01T15:12:00'),y:40},
               { x:new Date ('2022-08-01T15:13:00'),y:35},
               { x:new Date ('2022-08-01T15:14:00'),y:45},
               { x:new Date ('2022-08-01T15:15:00'),y:40},
              ],
              
            },
            /*{
              label:"RDIN957452565",
              borderColor:"LightSalmon",
              borderWidth:2,
              fill:false,
              //backgroundColor:"yellow",
              data:[
             { x:new Date ('2022-08-01T15:00:00'),y:30},
             { x:new Date ('2022-08-01T15:01:00'),y:33},
             { x:new Date ('2022-08-01T15:02:00'),y:45},
             { x:new Date ('2022-08-01T15:03:00'),y:34},
             { x:new Date ('2022-08-01T15:04:00'),y:30},
             { x:new Date ('2022-08-01T15:05:00'),y:50},
             { x:new Date ('2022-08-01T15:06:00'),y:30},
             { x:new Date ('2022-08-01T15:07:00'),y:45},
             { x:new Date ('2022-08-01T15:08:00'),y:50},
             { x:new Date ('2022-08-01T15:09:00'),y:32},
             { x:new Date ('2022-08-01T15:10:00'),y:40},
             { x:new Date ('2022-08-01T15:11:00'),y:38},
             { x:new Date ('2022-08-01T15:12:00'),y:30},
             { x:new Date ('2022-08-01T15:13:00'),y:35},
             { x:new Date ('2022-08-01T15:14:00'),y:42},
             { x:new Date ('2022-08-01T15:15:00'),y:45},
            ],
            
          },*/
    
          ]  
    } 
    
    const options={
     /* plugins:{
        streaming:{
          duration: 10000,  // data in the past 20000 ms will be displayed
          refresh: 1000,    // onRefresh callback will be called every 1000 ms
          pause:false,     // chart is not paused
          ttl:60000,   // data will be automatically deleted as it disappears off the chart
          frameRate: 30, 
        }
      },*/
      
        scales: {
            y: {
              min: 0,
              max: 80,

              ticks: {
                stepSize:10
              },
              
            },
            x: {
             /* type:'realtime',
             realtime: {
          onRefresh: function(chart) {
            Linechart.data.datasets.forEach(function(dataset) {
              dataset.data.push({
                x: Date.now(),
                y: Math.random()
              });
            });
          }
        },*/
                type: 'time',
                time: {
                 unit:'minute',
                },
                ticks: {
                 autoskip:true,
                 maxTicksLimit:4,
                },
                
              },
    },
};
/*const Pause=()=>{
  if(Linechart.options.plugins.streaming===false){
    Linechart.options.plugins.streaming=true;
  }
  else{
    Linechart.options.plugins.streaming=false;
  }
  Linechart.update({delay:0});
}*/
    return(
        <div>
        <Line
        data={data}
        options={options}
        height={30}
        width={70}
        />
        {/* <button onClick={()=>(Pause)}>Pause Chart</button> */}
        </div>
    );
};
export default Linechart;