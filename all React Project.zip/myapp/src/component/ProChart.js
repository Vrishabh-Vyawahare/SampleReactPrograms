import React from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import 'chartjs-adapter-date-fns';
import 'chartjs-adapter-luxon';
import { minutesToHours } from 'date-fns';
const ProChart = () => {
    const data={
        datasets:[
            {
                label:"RDIN124525654",
                borderColor:"OrangeRed",
                borderWidth:2,
                fill:false,
                tension:1,
                data:[
               { x:new Date ('2022-08-01T15:00:00'),y:60},
               { x:new Date ('2022-08-01T15:01:00'),y:60},
               { x:new Date ('2022-08-01T15:02:00'),y:59},
               { x:new Date ('2022-08-01T15:03:00'),y:59},
               { x:new Date ('2022-08-01T15:04:00'),y:59},
               { x:new Date ('2022-08-01T15:05:00'),y:59},
               { x:new Date ('2022-08-01T15:06:00'),y:59},
               { x:new Date ('2022-08-01T15:07:00'),y:59},
               { x:new Date ('2022-08-01T15:08:00'),y:59},
               { x:new Date ('2022-08-01T15:09:00'),y:59},
               { x:new Date ('2022-08-01T15:10:00'),y:59},
               { x:new Date ('2022-08-01T15:11:00'),y:58.5},
               { x:new Date ('2022-08-01T15:12:00'),y:58.5},
               { x:new Date ('2022-08-01T15:13:00'),y:58},
               { x:new Date ('2022-08-01T15:14:00'),y:58},
               { x:new Date ('2022-08-01T15:15:00'),y:58}
                ],},
                {
                    label:"RDIN143214326",
                    borderColor:"green",
                    borderWidth:2,
                    fill:false,
                    tension:1,
                    data:[
                   { x:new Date ('2022-08-01T15:00:00'),y:55},
                   { x:new Date ('2022-08-01T15:01:00'),y:55},
                   { x:new Date ('2022-08-01T15:02:00'),y:54},
                   { x:new Date ('2022-08-01T15:03:00'),y:54},
                   { x:new Date ('2022-08-01T15:04:00'),y:54},
                   { x:new Date ('2022-08-01T15:05:00'),y:54},
                   { x:new Date ('2022-08-01T15:06:00'),y:54},
                   { x:new Date ('2022-08-01T15:07:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:08:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:09:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:10:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:11:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:12:00'),y:53.5},
                   { x:new Date ('2022-08-01T15:13:00'),y:53},
                   { x:new Date ('2022-08-01T15:14:00'),y:53},
                   { x:new Date ('2022-08-01T15:15:00'),y:53}
                    ],},
                
            //    { x:new Date ('2022-08-01T15:16:00'),y:39},
            //    { x:new Date ('2022-08-01T15:17:00'),y:38},
            //    { x:new Date ('2022-08-01T15:18:00'),y:37},
            //    { x:new Date ('2022-08-01T15:19:00'),y:36},
            //    { x:new Date ('2022-08-01T15:20:00'),y:38},
            //    { x:new Date ('2022-08-01T15:21:00'),y:43},
            //    { x:new Date ('2022-08-01T15:22:00'),y:40},
            //    { x:new Date ('2022-08-01T15:23:00'),y:35},
            //    { x:new Date ('2022-08-01T15:24:00'),y:40},
            //    { x:new Date ('2022-08-01T15:25:00'),y:35},
            //    { x:new Date ('2022-08-01T15:26:00'),y:36},
            //    { x:new Date ('2022-08-01T15:27:00'),y:39},
            //    { x:new Date ('2022-08-01T15:28:00'),y:40},
            //    { x:new Date ('2022-08-01T15:29:00'),y:42},
            //    { x:new Date ('2022-08-01T15:30:00'),y:45},
            //    { x:new Date ('2022-08-01T15:31:00'),y:43},
            //    { x:new Date ('2022-08-01T15:32:00'),y:40},
            //    { x:new Date ('2022-08-01T15:33:00'),y:38},
            //    { x:new Date ('2022-08-01T15:34:00'),y:43},
            //    { x:new Date ('2022-08-01T15:35:00'),y:38},
            //    { x:new Date ('2022-08-01T15:36:00'),y:40},
            //    { x:new Date ('2022-08-01T15:37:00'),y:38},
            //    { x:new Date ('2022-08-01T15:38:00'),y:40},
            //    { x:new Date ('2022-08-01T15:39:00'),y:38},
            //    { x:new Date ('2022-08-01T15:40:00'),y:40},
            //    { x:new Date ('2022-08-01T15:41:00'),y:39},
            //    { x:new Date ('2022-08-01T15:42:00'),y:42},
            //    { x:new Date ('2022-08-01T15:43:00'),y:45},
            //    { x:new Date ('2022-08-01T15:44:00'),y:40},
            //    { x:new Date ('2022-08-01T15:45:00'),y:36},
            //    { x:new Date ('2022-08-01T15:46:00'),y:37},
            //    { x:new Date ('2022-08-01T15:47:00'),y:38},
            //    { x:new Date ('2022-08-01T15:48:00'),y:39},
            //    { x:new Date ('2022-08-01T15:49:00'),y:40},
            //    { x:new Date ('2022-08-01T15:50:00'),y:40},
            //    { x:new Date ('2022-08-01T15:51:00'),y:39},
            //    { x:new Date ('2022-08-01T15:52:00'),y:37},
            //    { x:new Date ('2022-08-01T15:53:00'),y:38},
            //    { x:new Date ('2022-08-01T15:54:00'),y:40},
            //    { x:new Date ('2022-08-01T15:55:00'),y:43},
            //    { x:new Date ('2022-08-01T15:56:00'),y:46},
            //    { x:new Date ('2022-08-01T15:57:00'),y:42},
            //    { x:new Date ('2022-08-01T15:58:00'),y:43},
            //    { x:new Date ('2022-08-01T15:59:00'),y:48},
            //    { x:new Date ('2022-08-01T16:00:00'),y:45},
             
               
              
              
            
            
          ]  
    } 
    const totalDuration =0;
    const delayBetweenPoints = totalDuration / data.length;
    const previousY = 
    (ctx) => ctx.index === 0 ? ctx.chart.scales.y.getPixelForValue(100) : ctx.chart.getDatasetMeta(ctx.datasetIndex).data[ctx.index - 1].getProps(['y'], true).y;
    const animation = {
      x: {
          type: 'number',
          easing: 'linear',
          duration: delayBetweenPoints,
          from: NaN, // the point is initially skipped
          delay(ctx) {
                      if (ctx.type !== 'data' || ctx.xStarted) {
                      return 0;
                      }
                        ctx.xStarted = true;
                        return ctx.index * delayBetweenPoints;
                      }
          },
       y:{
          type: 'number',
          easing: 'linear',
          duration: delayBetweenPoints,
          from: previousY,
         delay(ctx) {
                     if (ctx.type !== 'data' || ctx.yStarted) {
                     return 0;
                     }
                     ctx.yStarted = true;
                     return ctx.index * delayBetweenPoints;
                     }
          }
  };
  const options= {
   animation,
    interaction: {
      intersect: false
    },
    plugins: {
      legend: true
    },
    scales: {
      x: {
        ticks: {
            autoskip:true,
            maxTicksLimit:13,
           },
        type: 'time',
        time:{
            unit:'minute',
        }
      },
    },
    y: {min:0,
        max:80,
        ticks: {stepSize: 20}
        }
  }

return(
    <div>
     <Line data={data}
     options={options}
    animation={animation}
     height={40}
     width={100}
     />
    </div>
);
};
export default ProChart;