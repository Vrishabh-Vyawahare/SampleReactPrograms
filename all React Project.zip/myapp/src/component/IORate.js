import React from "react";
import { Line } from "react-chartjs-2";
import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import "chartjs-adapter-luxon";
import { minutesToHours } from "date-fns";
const IORate = () => {
  const data = {
    datasets: [
      {
        label: "RDIN143235672",
        borderColor: "grey",
        borderWidth: 2,
        fill: false,
        tension:0.2,
        data: [
          { x: new Date("2022-08-02T06:00:00"), y: 100 },
          { x: new Date("2022-08-02T07:00:00"), y: 35 },
          { x: new Date("2022-08-02T08:00:00"), y: 45 },
          { x: new Date("2022-08-02T09:00:00"), y: 40 },
          { x: new Date("2022-08-02T10:00:00"), y: 34 },
          { x: new Date("2022-08-02T11:00:00"), y: 35 },
          { x: new Date("2022-08-02T12:00:00"), y: 40 },
          { x: new Date("2022-08-02T13:00:00"), y: 35 },
          { x: new Date("2022-08-02T14:00:00"), y: 50 },
          { x: new Date("2022-08-02T15:00:00"), y: 32 },
          { x: new Date("2022-08-02T16:00:00"), y: 30 },
          { x: new Date("2022-08-02T17:00:00"), y: 48 },
          { x: new Date("2022-08-02T18:00:00"), y: 50 },
          { x: new Date("2022-08-02T19:00:00"), y: 32 },
          { x: new Date("2022-08-02T20:00:00"), y: 30 },
          { x: new Date("2022-08-02T21:00:00"), y: 48 },
          { x: new Date("2022-08-02T22:00:00"), y: 40 },
          { x: new Date("2022-08-02T23:00:00"), y: 35 },
          { x: new Date("2022-08-03T00:00:00"), y: 155 },
          { x: new Date("2022-08-03T01:00:00"), y: 35 },
          { x: new Date("2022-08-03T02:00:00"), y: 45 },
          { x: new Date("2022-08-03T03:00:00"), y: 1775 },
          { x: new Date("2022-08-03T04:00:00"), y: 1775 },
          { x: new Date("2022-08-03T05:00:00"), y: 45 },
        ],
      },
      {
        label: "RDIN1432987345",
        borderColor: "OrangeRed",
        borderWidth: 2,
        fill: false,
        tension: 0.2,
        //backgroundColor:"Pink",
        data: [
          { x: new Date("2022-08-02T06:00:00"), y: 200 },
          { x: new Date("2022-08-02T07:00:00"), y: 105 },
          { x: new Date("2022-08-02T08:00:00"), y: 100 },
          { x: new Date("2022-08-02T09:00:00"), y: 100 },
          { x: new Date("2022-08-02T10:00:00"), y: 104 },
          { x: new Date("2022-08-02T11:00:00"), y: 110 },
          { x: new Date("2022-08-02T12:00:00"), y: 115 },
          { x: new Date("2022-08-02T13:00:00"), y: 112 },
          { x: new Date("2022-08-02T14:00:00"), y: 112 },
          { x: new Date("2022-08-02T15:00:00"), y: 115 },
          { x: new Date("2022-08-02T16:00:00"), y: 118 },
          { x: new Date("2022-08-02T17:00:00"), y: 118 },
          { x: new Date("2022-08-02T18:00:00"), y: 119 },
          { x: new Date("2022-08-02T19:00:00"), y: 115 },
          { x: new Date("2022-08-02T20:00:00"), y: 115 },
          { x: new Date("2022-08-02T21:00:00"), y: 115 },
          { x: new Date("2022-08-02T22:00:00"), y: 112 },
          { x: new Date("2022-08-02T23:00:00"), y: 110 },
          { x: new Date("2022-08-03T00:00:00"), y: 210 },
          { x: new Date("2022-08-03T01:00:00"), y: 105 },
          { x: new Date("2022-08-03T02:00:00"), y: 1875 },
          { x: new Date("2022-08-03T03:00:00"), y: 1875 },
          { x: new Date("2022-08-03T04:00:00"), y: 105 },
          { x: new Date("2022-08-03T05:00:00"), y: 105 },
        ],
      },
    ],
  };
  const options = {
    scales: {
      y: {
          title:{
              display:true,
              color:'grey',
             text:'memory in bytes' 
          },
        min: 0,
        max: 2000,
        ticks: {
          stepSize: 500,
        },
      },
      x: {
        type: "time",
        time: {
          unit: "hour",
        },
        ticks: {
          autoskip: true,
          maxTicksLimit: 4,
        },
      },
    },
  };
  return (
    <div>
      <Line data={data} height={30} 
      options={options}width={70} />
    </div>
  );
};
export default IORate;
