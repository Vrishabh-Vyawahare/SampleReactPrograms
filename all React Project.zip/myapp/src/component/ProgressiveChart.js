import React from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import 'chartjs-adapter-date-fns';
import 'chartjs-adapter-luxon';
import { minutesToHours } from 'date-fns';
const ProgressiveChart = () =>
 {
   const data = [];
   const data2 = [];
   let prev = 100;
   let prev2 = 80;
   for (let i = 0; i < 1000; i++) 
   {
     prev += 5 - Math.random() * 10;
     data.push({x: i, y: prev});
     prev2 += 5 - Math.random() * 10;
     data2.push({x: i, y: prev2});
   }
      const totalDuration = 0;
      const delayBetweenPoints = totalDuration / data.length;
      const previousY = (ctx) => ctx.index === 0 ? ctx.chart.scales.y.getPixelForValue(100) : ctx.chart.getDatasetMeta(ctx.datasetIndex).data[ctx.index - 1].getProps(['y'], true).y;
      const animation = {
        x: {
            type: 'number',
            easing: 'linear',
            duration: delayBetweenPoints,
            from: NaN, // the point is initially skipped
            delay(ctx) {
                        if (ctx.type !== 'data' || ctx.xStarted) {
                        return 0;
                        }
                          ctx.xStarted = true;
                          return ctx.index * delayBetweenPoints;
                        }
            },
         y:{
            type: 'number',
            easing: 'linear',
            duration: delayBetweenPoints,
            from: previousY,
           delay(ctx) {
                       if (ctx.type !== 'data' || ctx.yStarted) {
                       return 0;
                       }
                       ctx.yStarted = true;
                       return ctx.index * delayBetweenPoints;
                       }
            }
    };
     const data1 ={
          datasets: [{
          borderColor:'red',
          borderWidth: 1,
          radius: 0,
          data: data,
        },
        {
          borderColor:'blue',
          borderWidth: 1,
          radius: 0,
          data: data2,
        }]
      };
      const options= {
        animation,
        interaction: {
          intersect: false
        },
        plugins: {
          legend: false
        },
        scales: {
          x: {
            type: 'linear'
          }
        }
      }
   
    return(
        <div>
         <Line data={data1}
         options={options}
        animation={animation}
         height={40}
         width={100}
         />
        </div>
    );
};
export default ProgressiveChart;