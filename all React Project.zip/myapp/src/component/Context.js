import { Line } from "react-chartjs-2";
import Usecontext from "./component/Usecontext";
import Chart from "chart.js/auto";
import { createContext } from "react";
export const GlobalInfo = createContext();
function Context() {
  const Data = {
    labels: ["SHV", "BJP", "INC", "NCP", "IND"],
    datasets: [
      {
        label: "RDIN143235672",
        borderColor: "grey",
        borderWidth: 2,
        data: [56, 106, 44, 54, 28],
      },
    ],
  };
  return (
    <Context.Provider value={Data}>
      <Usecontext />
    </Context.Provider>
  );
}
export default Context;
