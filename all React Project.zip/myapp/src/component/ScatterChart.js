import React from "react";
import { Scatter } from "react-chartjs-2";
import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import "chartjs-adapter-luxon";
import { minutesToHours } from "date-fns";
const ScatterChart = () => {
  const data = {
    datasets: [
      {
        labels:"Scatter chart",
        borderColor: "grey",
        pointStyle:'star',
        borderWidth: 1,
        fill: false,
        backgroundColor:"grey",
        data: [
          { x: new Date("2022-08-02T06:00:00"), y: 70 },
          { x: new Date("2022-08-02T06:15:00"), y: 35 },
          { x: new Date("2022-08-02T06:30:00"), y: 40 },
          { x: new Date("2022-08-02T06:45:00"), y: 65 },
          { x: new Date("2022-08-02T07:00:00"), y: 20 },
          { x: new Date("2022-08-02T07:15:00"), y: 35 },
          { x: new Date("2022-08-02T07:30:00"), y: 76 },
          { x: new Date("2022-08-02T07:45:00"), y: 82},
          { x: new Date("2022-08-02T07:55:00"), y: 55 },
          
          
        ],
      },],
    };
    const options = {
      plugins: {
        legend: {
            display: false,
            }
        },
      scales: {
        y: {
            /*title:{
                display:true,
                color:'grey',
               text:'memory in bytes' 
            },*/
          min: 0,
          max: 100,
          ticks: {
            stepSize: 10,
          },
        },
        x: {
          type: "time",
          time: {
            unit: "minute",
          },
          ticks: {
            autoskip: true,
            maxTicksLimit: 8,
          },
        },
      },
    };
    return (
      <div>
        <Scatter data={data} height={30} 
        options={options}width={70} />
      </div>
    );
  };
  export default ScatterChart;
  
