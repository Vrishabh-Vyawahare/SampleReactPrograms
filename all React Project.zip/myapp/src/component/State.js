import React, { Component } from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
class State extends Component {

constructor()
{
      super();
      this.state = 
    {
      chartData:
       {
           labels:['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'],
           datasets:
           [
               {
                   data:[20,50,24,25,64,35],
                   label:'RDIN123987456',
                   backgroundColor:'Gainsboro',
                   borderWidth:2,
                   borderColor:"OrangeRed",
                   tension:0,
                   fill:true,
               }
           ]
       }
    }

}
render()
    {
        return(
         <div> 
             
             <Line data={this.state.chartData} 
             height={30} 
             width={70}
             options={{
                scales: {
                    y: {
                        beginAtZero: true,
                    },
                   
            },
             }}
             /> 
               
        </div> 
        )
    }
};
export default State;
    