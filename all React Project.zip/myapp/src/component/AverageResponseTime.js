import React from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
import 'chartjs-adapter-date-fns';
import 'chartjs-adapter-luxon';
import { minutesToHours } from 'date-fns';
const AverageResponseTime = () => {
    const data={
        datasets:[
            {
                label:"api/Search",
                borderColor:"green",
                borderWidth:2,
                fill:false,
                //backgroundColor:"Pink",
                data:[
               { x:new Date ('2022-08-01T15:00:00'),y:0.5},
               { x:new Date ('2022-08-01T15:01:00'),y:1.0},
               { x:new Date ('2022-08-01T15:02:00'),y:0.7},
               { x:new Date ('2022-08-01T15:03:00'),y:0.8},
               { x:new Date ('2022-08-01T15:04:00'),y:0.9},
               { x:new Date ('2022-08-01T15:05:00'),y:1.1},
               { x:new Date ('2022-08-01T15:06:00'),y:0.7},
               { x:new Date ('2022-08-01T15:07:00'),y:0.8},
               { x:new Date ('2022-08-01T15:08:00'),y:1.1},
               { x:new Date ('2022-08-01T15:09:00'),y:1.4},
               { x:new Date ('2022-08-01T15:10:00'),y:1.2},
               { x:new Date ('2022-08-01T15:11:00'),y:1.1},
               { x:new Date ('2022-08-01T15:12:00'),y:0.8},
               { x:new Date ('2022-08-01T15:13:00'),y:0.9},
               { x:new Date ('2022-08-01T15:14:00'),y:1.2},
               { x:new Date ('2022-08-01T15:15:00'),y:1.3},
              ],
              
            },
            {
              label:"api/health",
              borderColor:"red",
              borderWidth:2,
              fill:false,
              //backgroundColor:"yellow",
              data:[
             { x:new Date ('2022-08-01T15:00:00'),y:0.6},
             { x:new Date ('2022-08-01T15:01:00'),y:1.2},
             { x:new Date ('2022-08-01T15:02:00'),y:1.2},
             { x:new Date ('2022-08-01T15:03:00'),y:1.1},
             { x:new Date ('2022-08-01T15:04:00'),y:0.8},
             { x:new Date ('2022-08-01T15:05:00'),y:0.4},
             { x:new Date ('2022-08-01T15:06:00'),y:0.6},
             { x:new Date ('2022-08-01T15:07:00'),y:0.5},
             { x:new Date ('2022-08-01T15:08:00'),y:0.6},
             { x:new Date ('2022-08-01T15:09:00'),y:0.8},
             { x:new Date ('2022-08-01T15:10:00'),y:0.9},
             { x:new Date ('2022-08-01T15:11:00'),y:0.8},
             { x:new Date ('2022-08-01T15:12:00'),y:1.3},
             { x:new Date ('2022-08-01T15:13:00'),y:0.8},
             { x:new Date ('2022-08-01T15:14:00'),y:0.7},
             { x:new Date ('2022-08-01T15:15:00'),y:0.9},
            ],
            
          },
          {
            label:"Rating/Quote",
            borderColor:"blue",
            borderWidth:2,
            fill:false,
           // backgroundColor:"blue",
            data:[
           { x:new Date ('2022-08-01T15:00:00'),y:0.7},
           { x:new Date ('2022-08-01T15:01:00'),y:0.5},
           { x:new Date ('2022-08-01T15:02:00'),y:0.8},
           { x:new Date ('2022-08-01T15:03:00'),y:1.1},
           { x:new Date ('2022-08-01T15:04:00'),y:1.0},
           { x:new Date ('2022-08-01T15:05:00'),y:0.7},
           { x:new Date ('2022-08-01T15:06:00'),y:0.4},
           { x:new Date ('2022-08-01T15:07:00'),y:0.6},
           { x:new Date ('2022-08-01T15:08:00'),y:0.8},
           { x:new Date ('2022-08-01T15:09:00'),y:1.0},
           { x:new Date ('2022-08-01T15:10:00'),y:1.2},
           { x:new Date ('2022-08-01T15:11:00'),y:1.3},
           { x:new Date ('2022-08-01T15:12:00'),y:1.5},
           { x:new Date ('2022-08-01T15:13:00'),y:1.4},
           { x:new Date ('2022-08-01T15:14:00'),y:1.1},
           { x:new Date ('2022-08-01T15:15:00'),y:1.0},
          ],
          
        },
          ]  
    } 
    const options={
        scales: {
            y: {
              min: 0,
              max: 2,
              

              ticks: {
                stepSize:10
              },
              
            },
            x: {
                type: 'time',
                time: {
                 unit:'minute',
                },
                ticks: {
                 autoskip:true,
                 maxTicksLimit:4,
                },
                
              },
    },
};
    return(
        <div>
        <Line
        data={data}
        options={options}
        height={30}
        width={70}
        />
        </div>
    );
};
export default AverageResponseTime;
