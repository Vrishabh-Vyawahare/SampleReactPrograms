import { useContext } from "react";
import Chart from "chart.js/auto";
import { Line } from "react-chartjs-2";s
import GlobalInfo from "./component/Context.js";
function Usecontext() {
  const Data = useContext(GlobalInfo);
  return (
    <div>
      <Line data={Data} height={30} width={60} />
    </div>
  );
}
export default Usecontext;
