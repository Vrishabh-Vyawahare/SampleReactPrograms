import React from 'react';
import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto';

const BarChart = () => { 

        const data = {
        labels: ['Jan','Feb','March','April','May','June','July'],
        datasets: [{
          label: 'My First Dataset',
          data: [65, 59, 80, 81, 56, 55, 40],
          backgroundColor:'grey',
          borderColor: 'black',
          borderWidth: 1,
          barThickness:50
  }]
};
        
        const options={
            scales: {
                y: {
                    beginAtZero: true,
                },
        },
    };
        return(
            <div>
            <Bar
            data={data}
            options={options}
            height={30}
            width={70}
            />
            </div>
        );
    };
    export default BarChart;