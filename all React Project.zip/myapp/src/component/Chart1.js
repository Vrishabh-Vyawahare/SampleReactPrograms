import React from 'react';
import { Line } from 'react-chartjs-2';
import Chart from 'chart.js/auto';
const Chart1 = () => {
    const data={
        labels:['Jan','Feb','Mar','Apr','May'],
        datasets:[
            {
                label:"sales for 2020",
                borderColor:"green",
                borderWidth:2,
                fill:false,
                backgroundColor:"Pink",
                data:[25,40,65,10,90],
            },
            {
                label:"sales for 2021",
                data:[20,50,35,85,60],
                borderColor:"red",
                borderWidth:2,
                fill:true,
                backgroundColor:"Blue",
            },
            {
                label:"sales for 2022",
                data:[10,35,90,40,63],
                borderColor:"blue",
                borderWidth:2,
                fill:false,
                backgroundColor:"teal",
            }
        ]      
    };
    return(
        <div>
        <Line
        data={data}
        height={30}
        width={60}
        />
        </div>
    );
};
export default Chart1;