import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto'
import { useState, useEffect } from "react";

function Effect() {
  const [Data, setData] = useState({datasets:[]});

  useEffect(() => {
    setData({
     labels:['Jan','Feb','March','April','May'],
     datasets:
           [
               {
                   data:[20,50,80,45,64],
                   label:'RDIN123987456',
                   backgroundColor:['Chartreuse','cyan','Gold','blue','Coral'],
                   borderWidth:1,
                   barThickness:80
               }
           ]
    },
  )},[])
  return(
      <div>
       <Bar data={Data}
       height={30}
       width={80}
       options={{
        scales: {
          y: {
  
        min: 0,
        max: 100,
        ticks: {
          stepSize: 20,
        },
          },
         
  },
       }}/>
      </div>
  )
};
export default Effect;