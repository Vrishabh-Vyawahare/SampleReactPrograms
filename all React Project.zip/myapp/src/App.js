import React from 'react'
//import Chart1 from './component/Chart';
//import Linechart from './component/Linechart';
//import AverageResponseTime from './component/AverageResponseTime';
// import ProgressiveChart from './component/ProgressiveChart';
//import ProChart from './component/ProChart';
//import ScatterChart from './component/ScatterChart';
//import IORate from './component/IORate'
//import Effect from './component/Effect';
// import Context from './component/Context';
import './App.css';
import BarChart from './component/BarChart';
//import State from './component/State.js'
function App() {
  return (
    <div> 
      {/* <Linechart />  */}
      {/* <AverageResponseTime />   */}
        {/* <ProgressiveChart />   */}
     {/* <ProChart />  */}
     {/* <IORate />  */}
     {/* <ScatterChart />   */}
    <BarChart /> 
   {/* <State /> */}
    {/* <Effect />  */}
    {/* <Context /> */}
    </div>
  );
}
export default App;