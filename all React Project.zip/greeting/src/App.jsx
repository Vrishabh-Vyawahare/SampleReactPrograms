import './App.css';
function App(){
    let Current_date=new Date();
    Current_date=Current_date.getHours();
    let greeting='';
    const style={ };

if(Current_date>=6 && Current_date<12)
{
  greeting='Good Morning';
  style.color='green';
}

else if
(Current_date>=12 && Current_date<17)
{
  greeting='Good Afternoon';
  style.color='red';
}
else if
(Current_date>=17 && Current_date<=19)
{
  greeting='Good Evening';
  style.color='orange';
}
else

{
  greeting='Good night';
  style.color ='black';
}
    return(
        <>
        <h1>Hello sir, <span style={style}>{greeting}</span></h1>
        </>
    )
}
export default  App;