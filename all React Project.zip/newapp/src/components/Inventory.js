import {Component} from 'react'
import InputItemRow from './InputItemRow';
import ItemRow from './ItemRow';
class Inventory extends Component {
    constructor() {
      super();
      this.state={
          items:[
              {id:1,name:'Rice',unit:'2kg',stock:'100kg',price:4000},
              {id:2,name:'Wheat',unit:'10kg',stock:'500kg',price:5000},
              {id:3,name:'Oil',unit:'1lit',stock:'100lit',price:12000},
              {id:4,name:'Sugar',unit:'2kg',stock:'200kg',price:5000},
              {id:5,name:'Dal',unit:'1kg',stock:'100kg',price:5000},
          ]
      }
    
    }
    addItem=item=>{
      this.setState({items:[...this.state.items,{...item}]})
    }
    updateItem=item=>{
      this.setState({items:this.state.items.map(t=>t.id===item.id ?{...item,undefined:true}:t)});
    }
    deleteItem=id=>{
      this.setState({items:this.state.items.filter(t=>t.id!==id )});
    }
    markEditable=id=>{
      this.setState({items:this.state.items.map(t=>t.id===id?{...t,editable:true}:t)});
    };
    unMarkEditable=id=>{
        this.setState({items:this.state.items.map(t=>t.id===id?{...t,editable:undefined}:t)});
            };
            render() {
              return (
                  <div className='col-sm-10 mx-auto'>
                      <h4>Inventory</h4>
                      <div className='row border-bottom border-primary p-1 fw-bold'>
                          <div className='col-sm-1'>Item#</div>
                          <div className='col'>Name</div>
                          <div className='col-sm-2'>Rate</div>
                          <div className='col-sm-2'>Stock</div>
                          <div className='col-sm-2'>Unit</div>
                          <div className='col-sm-2'></div>
                      </div>
                      
                      <InputItemRow add={this.addItem}/>
                      {this.state.items.map(t => (
                          t.editable ?
                              <InputItemRow Key={t.id} item={t} unMarkEditable={this.unMarkEditable} update={this.updateItem}/> :
                              <ItemRow Key={t.id} item={t} markEditable={this.markEditable} remove={this.deleteItem}/>
                      ))}
                      
                  </div>
              );
          }
}
  export default Inventory;