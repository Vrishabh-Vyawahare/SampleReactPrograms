import {Fragment} from'react'
import Header from './components/Header.js'
import Inventory from './components/Inventory.js'

function App() {
  return (
    <Fragment>
       <Header brand="Inventory Management App"/>
       <Inventory />
    </Fragment>
  );
}

export default App;