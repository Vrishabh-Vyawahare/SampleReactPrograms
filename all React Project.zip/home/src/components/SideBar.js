import { useState } from 'react'
import { Link } from 'react-router-dom'
import { Data } from './Data'
import {FaBars,FaTimes } from "react-icons/fa";
import './SideBar.css';
import DTRange from './DTRange'
import User from './User'

function SideBar() {
    const [close, setClose] = useState(false)
    const showSidebar = () => setClose(!close)
    return (
         <div className='whole'>
             <div className='Navbar'>
              <nav>
              <Link to='#'className='open' >
              <FaBars onClick={showSidebar} />
              </Link>
              </nav>
             

              <nav className='date'>
             <DTRange /> 
              </nav> 

             <nav  className='User'>
             <User />
             </nav>

             </div>
              
             <nav className={close ? 'nav-menu active' : 'nav-menu'}>
             <ul >
             <Link to='#' className='Close'  onClick={showSidebar}>
             <FaTimes />
             </Link>
                {Data.map((item, index) => {
                    return (
                        <li className='list' key={index}>
                            <Link className='item-link' to={item.path}>
                                {item.icon}
                                <span style={{marginLeft: '35px'}}>{item.title}</span>
                            </Link>
                        </li>
                    )
                })}
                </ul>
                </nav>
              
          
                </div>
    )
}

export default SideBar;