import React from 'react'
import {FaUserCircle} from "react-icons/fa";

function User(){
    return(
        <div>
         <h1> <FaUserCircle /></h1>
        </div>
    );
};
export default User;