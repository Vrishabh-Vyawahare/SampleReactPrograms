import React from 'react'
import {FaHome,FaTasks,FaUserAlt  } from "react-icons/fa";
import { AiFillSetting } from "react-icons/ai"; 
import { SiSimpleanalytics } from "react-icons/si";

export const Data = [
    {
        title: 'Home',
        path: '/',
        icon: <FaHome />
    },
    {
        title: 'Task',
        path: '/task',
        icon: <FaTasks />
    },
    {
        title: 'Analysis',
        path: '/analysis',
        icon: < SiSimpleanalytics/>
    },
    {
        title: 'Setting',
        path: '/setting',
        icon: <AiFillSetting />
    },
    {
        title: 'Profile',
        path: '/profile',
        icon: < FaUserAlt/>
    }
]