import React from 'react'
const mystyle={
    display: 'flex',
    alignItems: 'center',
   
}
function Home(){
   
    return(
        <div style={mystyle}>
            <h1>
                Home
            </h1>
            <p>Basic Paragraph Format
It is important to note that a paragraph does not have a minimum or maximum number of sentences that it must have to fit the definition of a paragraph. Some writers will opt to use very short paragraphs, while others will include dozens of sentences in their paragraphs. It is also important to know that most writers separate lines of dialogue into paragraphs, so if a character only speaks a single line, it will be its own paragraph.

Keeping that in mind, there is a general agreement on the format of a standard paragraph, which especially applies to informational and argumentative or persuasive writing. A paragraph should be divided into three distinct sections that each serve a purpose to the paragraph as a whole. </p>
 </div>
    )
}
export default Home;
