import React from 'react'
const mystyle={
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
   
}
function Setting(){
    return(
        <div style={mystyle}> 
            <h1>
                Setting
            </h1>
        </div>
    )
}
export default Setting;