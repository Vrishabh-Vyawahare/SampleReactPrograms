import React from 'react'
const mystyle={
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
   
}
function Analysis(){
    return(
        <div style={mystyle}>
            <h1>
            Analysis
            </h1>
        </div>
    )
}
export default  Analysis;