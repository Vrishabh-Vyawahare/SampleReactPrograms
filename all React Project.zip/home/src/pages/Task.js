import React from 'react'
const mystyle={
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
   
}
function Task(){
    return(
        <div style={mystyle}>
            <h1>
                Task
            </h1>
        </div>
    )
}
export default Task;