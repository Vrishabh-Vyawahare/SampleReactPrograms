import React from 'react'
const mystyle={
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
   
}
function Profile(){
    return(
        <div style={mystyle}>
            <h1>
                Profile
            </h1>
        </div>
    )
}
export default Profile;