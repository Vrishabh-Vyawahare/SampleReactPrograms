import React from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import SideBar from './components/SideBar'
import Home from './pages/Home';
import Setting from './pages/Setting';
import Task from './pages/Task';
import Profile from './pages/Profile';
import Analysis from './pages/Analysis';
import './App.css'

function App(){
  return (
      <div>
      <Router>
       <SideBar />
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/profile' element={<Profile/>} />            
          <Route path='/task' element={<Task />} />    
          <Route path='/setting' element={<Setting />} />
          <Route path='/analysis' element={<Analysis />} />
        </Routes>
      </Router> 
    
      </div>
  
  )
}

export default App;
