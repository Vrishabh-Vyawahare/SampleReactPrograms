import React,{useReducer} from 'react'

const initialState=0;
const Reducer=(state,actions)=>{
    if(actions.type==='INC')
    {
        return state+1;
    }
    if(actions.type==='DEC')
    {
        return state-1;
    }

    return state;
}
function URExample(){
    const[state,dispatch]=useReducer(Reducer,initialState);
    
    

    return (
    <>
    <h1>{state}</h1>
    <button onClick={()=>dispatch({type:'INC'})}>INCREMENT</button>
    <button onClick={()=>dispatch({type:'DEC'})}>DECREMENT</button>
    </>
    )
  }
  
  export default URExample;