import React from 'react';
import ReactDOM from 'react-dom/client';
// import Create from './CRUD/Create';
// import DateTimeInput2 from './DateTime/DateTimeInput2';
// import InputDate from './DateTime/InputDate';
// import './index.css';
// import ToDoList1 from './ToDoList/ToDoList1';
// import { BrowserRouter } from 'react-router-dom';
import App from './Navigation/App'
// import BarChart from './Chartjs/BarChart';
import 'bootstrap/dist/css/bootstrap.min.css';          
// import Main from './Ecommerce/Main';
// import TableData from './CRUD/TableData';
import { BrowserRouter } from 'react-router-dom';
//  import App from './App';
// import App from './Ecommerce/App'


const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <>
  <BrowserRouter>
   <App />
  </BrowserRouter>

  {/* <BarChart /> */}
  {/* <ToDoList1 /> */}
  {/* <DateTimeInput2 /> */}
  {/* <InputDate /> */}
  {/* <Create /> */}
  {/* <TableData /> */}
  {/* <BrowserRouter>
  <App />
  </BrowserRouter> */}
 {/* <Main /> */}
 {/* <BrowserRouter>
  <App />
  </BrowserRouter> */}
  </>
    
 
);


