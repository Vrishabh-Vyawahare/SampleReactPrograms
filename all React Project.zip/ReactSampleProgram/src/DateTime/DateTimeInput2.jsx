import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import React,{useState} from 'react';
const DateTimeInput2 =()=>{
    const [value, onChange] = useState(new Date());
    return (
      <div>
        <DatePicker
        selected={value}
        onChange={onChange}
        autoFocus
        dateFormat={'dd-MM-yyyy hh:mm aa'}
        isClearable
        showIcon
        showMonthDropdown
        showYearDropdown
        dropdownMode="select"
        placeholderText={"Enter a Date"}
        shouldCloseOnSelect={true}
        //showTimeSelect
        showTimeInput
        timeInputLabel={'TIME'}
        todayButton={'Today'}
        // excludeDates={ new Date() }
        filterDate={(date) => {
          return date.getDay() !== 0 && date.getDay() !== 6;    // Disable weekends (Saturday and Sunday)
        }}
        >
        
       <div style={{ color: "red" }}>Don't forget to check the weather!</div>

       </DatePicker>
      </div>
    );
// const [dateRange, setDateRange] = useState([null, null]);
// const [startDate, endDate] = dateRange;
// return (
//   <DatePicker
//     selectsRange={true}
//     startDate={startDate}
//     endDate={endDate}
//     onChange={(update) => {
//       setDateRange(update);
//     }}
//     isClearable={true}
//   />
// );
  }
  
  export default DateTimeInput2;