import { useState } from 'react';
import DateTimePicker from 'react-datetime-picker';
import 'react-datetime-picker/dist/DateTimePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-clock/dist/Clock.css';
function InputDate() {
    const [value, onChange] = useState(new Date());
    return (
      <div>
    <DateTimePicker 
    value={value} 
    onChange={onChange}
    monthPlaceholder={" "} 
    filterDate={(date)=>date.getDay!=='0'}   
    />
      </div>
    );
  }
  
  export default InputDate;