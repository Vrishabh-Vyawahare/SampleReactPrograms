import DateTimeRangePicker from '@wojtekmaj/react-datetimerange-picker';
import '@wojtekmaj/react-datetimerange-picker/dist/DateTimeRangePicker.css';
import 'react-calendar/dist/Calendar.css';
import 'react-clock/dist/Clock.css';
import React,{useState} from 'react';
function DateTimeInput() {
    const [value, onChange] = useState([new Date(), new Date()]);
    return (
      <div>
        <DateTimeRangePicker
        onChange={onChange} 
        value={value}
        format={'dd-MM-yyyy HH:mm'} 
        disableClock={'true'} 
        rangeDivider={'To'}
        minDate={new Date(2023,7,1)}
        maxDate={new Date(2023,8,1)}
        autoFocus={'true'}/>
      </div>
    );
  }
  
  export default DateTimeInput;