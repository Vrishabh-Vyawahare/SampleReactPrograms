import {Button,Table} from 'react-bootstrap';
import React,{useState,useEffect} from 'react'
import  {Link,useNavigate} from 'react-router-dom';


function TableData() {

  const [user, setUser] = useState(null);

  const navigation=useNavigate();

  const EditHandler=(index)=>{
   navigation(`/EditData/${index}`)
  }
 
  const DeleteHandler=(index)=>{
    
      fetch( `http://localhost:3000/posts/${index}`,
      { method: "DELETE" })
      .then((res)=>{
        return res.json(); 
        })
        .then((res)=>{
          alert('Record deleted');
          window.location.reload();    //refresh page using js reload()
        })
    }

  useEffect(()=>{
    fetch('http://localhost:3000/posts')
    .then((res)=>{
    return res.json(); 
    })
    .then((res)=>{
        setUser(res);
        console.log(user);
    })

},[])


  return(
    <>
    <h1 className='text-center'>React JS CRUD Operation</h1>
    <Link to="/formdata" className='btn btn-success '>Add User</Link>

    <Table striped bordered hover >
      <thead>
        <tr>
          <th>Id</th>
          <th>Name</th>
          <th>EmailId</th>
          <th>Mobile Number</th>
          <th>actions</th>
        </tr>
      </thead>
      <tbody>
          {user &&
            user.map((value)=>(
              <tr key={value.id}>
                <td>{value.id}</td>
                <td>{value.name}</td>
                <td>{value.email}</td>
                <td>{value.phone}</td>
                <td>
                <Button variant='success'onClick={()=>EditHandler(value.id)}>Edit</Button>
                <Button variant='danger' onClick={()=>DeleteHandler(value.id)}>Delete</Button>
                </td>
                </tr>
                )) 
               }
       </tbody>
       </Table>
    </>
  ) 
  }
  
  export default TableData;