import {Button}from 'react-bootstrap';
import React,{useState} from 'react'
import {useNavigate,Link} from 'react-router-dom'


function FormData() {
const[id,setId] =useState(""); 
const[name,setName]=useState("");
const[email,setEmail]=useState("");
const[phone,setPhone]=useState("");

const setNameHandler=(e)=>{setName(e.target.value)}
const setEmailHandler=(e)=>{setEmail(e.target.value)}
const setPhoneHandler=(e)=>{setPhone(e.target.value)}

const navigation=useNavigate();

const SubmitHandler=(e)=>{
  e.preventDefault();
  const empdata = {id,name,email,phone}       
 
      fetch('http://localhost:3000/posts',{
      method:"POST",
      headers:{"content-type":"application/json"},
      body:JSON.stringify(empdata)
      }).then((res)=>{
      return res.json(); 
      })
      .then((res)=>{
          alert('Record inserted');
          navigation('/');
      })
     }
  return (
    <>
    <form>
        
        <label>Name</label>
        <br/>
        <input type="text" placeholder='Enter a name' onChange={setNameHandler} value={name}/>
        <br/>
        <label>Email</label>
        <br/>
        <input type="email" placeholder='Enter a Email' onChange={setEmailHandler} value={email}/>
        <br/>
        <label>Phone number</label>
        <br/>
        <input type="number" placeholder='Enter a Phone Number' onChange={setPhoneHandler} value={phone}/>
        <br/><br/>
        
        <Button type="submit" className='btn btn-success' onClick={SubmitHandler}>Submit</Button>
        <Link to="/" className='btn btn-danger'>Back</Link>

    </form></>
  );
}

export default FormData;