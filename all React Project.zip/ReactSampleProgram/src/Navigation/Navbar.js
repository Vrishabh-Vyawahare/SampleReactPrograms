import React, {useState} from "react";
import './Navbar.css';
import { Link } from "react-router-dom";
import { GiHamburgerMenu } from "react-icons/gi";


const Navbar = () => {

  const[show,setShow]=useState(false)
  const img1="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAFXUlEQVR4Ac1XA5RlSQwdz9q2bdu2bdu2d2zbZtu2bdvm192bOvV6/7Re9yxzTj7eSyWpG1WNMCXXicJjyGeS3yZvJmeSm8g2zU362WYtc6ZeY67fxPBo8mXkeeQCspWMES4TyL/34gmQd1qmQK+5TOsYtmHho8gTyNWG0VHkQ7xm4JzAJbgxYh3uid6M+2K2yG/17CDPGRhJGSdnqrWOo7TOIRu/lBxMdoiy8W6TcXnoSnyW7o/fssOxsSwdWyuysIXsVVMAt6o8RDWUY3tlNr7NDFay49wmGY44tK5LtW5T4zfqeIoC7mwxfssJx89ZIdhRkY21pWlwqZTvVLhU5dJwGQraG1HX3YEWaze67DbUdrdjYVECzgpY5IxGptYtNgY0fplhfDT54Zit+DU7DJvKM7BNdlyeiQn8n9FSi+quNjgwOGW21ikdo1x3ceKy3k44xzzIMP543HYazMCK4mRs5PenaX5IbKpCg6UTw6FaIvNykjudUA4IB2lbuxgfRZ5gwP5o7Hb8kh2KWfkxcGd8V5WkILaxArtLDIkg4RyOCdpmjwOXk6tEQOK2mvENqSvBsuIkvJHojmZrF/4qMRzOOVElNg0HRuuaVdn+SZo/PkjxRlBdsUq4vLYGmFGHzYrC9iYUdzSrJByIJDHHsDo0CvOUbd218sWzK0NXwbM6HxtYZi8muCCLXg+F3FgNJ/nNw6UhK5A7iMM1DMUVLFGNQr6yrVunZSQz9fUkDxXvcJbWejphdzgwFJrGXBmx8zeczZKtYnUMRr/nRBgOWJRt3b9xMDvcoqJEzCmIw9cZQWi1WWCQuNFo6UIBYc7hDqUErQ47DHo/zY8O/IpbIzfwXbuSE25lX+hNEdzcAZ7TdRhoW2pTPDozYLGC36+mEAsLE2BQPctoQm4kLg9ZiWN85uBI79lqp5+mB6gSsxGlh2K3KQTOoI7rwtfgaMod5zsXd0RuVB3SmQQhadsahUxxoFGGyQ3h6zAtLxorGQLZoZAk1NtMyJF8v7/HVNwWuYEG1mIcvR9Jg9Mp38xdXkbnRMdYJtgVzKPbaHgfygsqD0ZvoR4rDOrkb3kv8sq2jFP58wDrNJil91NmiGqpQmH1pTiQcI1jdcwvjEc3HZKWK7IHMWQfpPqqNnyi33wa+x3PxLtIo1KOv0nHBZVziZZsyCBB7LG4HYYDVsMB2Z20XNVwjOSbnBsFlVys34rOVhgkv6WuBc5oQiwxleHjUpkDgyYTHVl7QdBSaUSDOqBCcFPEejXdgoiCQW8le2HEDpVcqtYNBYJCDZPNwkTczgE1xnWSQiqusfLPtURA1t7BtZ22wUOgkvDcoCVwZdsNY5Ya9Gayp1JyPnchTUbIi4l6Ef9fwESSSTiXVSPK9nafqvqBUDqH1ZlETRD4JjPINAmlDNUOlpUko6SzBQatYEJKwsk0u5rJ9RShk+wWp+6O2qRK82NVgr8pJ073X4inKXMuDcizE33ncYBVm5WhbkT06EOZeM09C1Qy/pgVqs4EchISJ0/xX4DX2LCkRdvhwEdcw92yiXni0uAVOIgyh3nPwvVhaxQiDtNG5NSKLwxehshedSsxF9jSWmqQ2lyDMiJksdt7GlS9pQOVfN+tDyKplJMEbSI6Q23FxjBSg2Iqs/ev0/CGkfM4ZsktVjv46zT0cdz7QKIODwLnXyfzA0m/R7JRZDlGSa//q6SOZImDHckGOJRK6dFr83D85UOpybFc4sbkGRYalO3vWJ418LHc5GIifV4uG6xhlmmZlKW0VClRYfktz+SdyJhfTHb3ajaSLF1MWqn0cxkqwvJbnvGd+dXs/385/Zev538A20ygDkpS0poAAAAASUVORK5CYII="
  const img2="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAV1BMVEVHcEz////////////////////////////////////C6P2o3Px7y/ppxPqJ0Pvc8/4AoPcApPcAnPZPu/kAp/j///////8ttPma1vvx+/4Brfj///////852j2iAAAAHXRSTlMAP4K05M7BCpL///////////////8HGP///v8PXU/3rSQAAAG3SURBVHgBbc/RYqQgDIVhdKg1BOQkpAXovP9zruOunbHd75bfJLoX03zz3r8t8+T+430lChxT2jgTre/uh5lyBOQAxEzz9XNPWQvsJBrJf7hvn5Rr1Zzxklimz/P9g4KW3FRLr/JdINB5iKfcoGh9lFRhJ2R/3gdpxEAam0ayc4gIrW73Ra1W0UabopGaNJxFoq89WPO+OxoQelWUoCFAziWPEdTBZiEPFGIFb6oxyTnCuYnUOAyLYxPlXoEQazfYA2hyc8AwK5QkZEOhqBKgFnAEYXULy9iZcZHUBDkDpQvzoxBenI8yDiWYhCgaqSIlVX4E0buebPxlharkJIUS0EvqMCl0Bodaxmgme4WxQYtI6s8Vh9aksoEbEEsJ2Ly78Wtgo4xUDRtDGAO8HL/5qmazMJACUOqWZzeR2KWwfUQ0SUEtG03O0SbjwkKVrUpiYCPn3NxhPwpLoxla1D47d4644LQ3CI3cw52GjSsbtQZUurvD0sXG7zukv7l/fJZfW6pk7775Xq+XGmr37sWNGM/EBI1u7mIi4grIDlqZzvte3D1RYG4cOvnz+er9vt6W5bbev9zTH1qSOsOOk/mZAAAAAElFTkSuQmCC"
  const img3="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAllBMVEVHcEzVWlvFERrGGCHKKjHFDBbXbXDHFyDMMDfbd3vtoqTLMTjvt7v////QRUvp6u8+mso6lshjqtIukcUAgL0Ph8FcqdNwvNxdqdIlj8UAf71KoM3NO0EGg78jjMM/msrEAxDtsLTXZ2zT4uzZaG3Zb3PHGiPeg4dRmskuj8SRyOIVhcDWWVyg0ed3udoAh8DTVFm23u7vGPHlAAAAMnRSTlMAY/+49/+BsKJoG947BboO06pv3v/+nymH9/+70f/okv9PeB+gNv9FWbtf81c/h0WJTDxiybwAAAEvSURBVHgB7ZGFgUMhEAXfd3cNFnfvv7nbPbd0kMFhcDziiWUzDlzKPf8/wWMhgOs9EmwmhMtF9I8QJzw1zXiHvEBJVHXTdv0wTkQnCxSKhSL0bM8FoIUQuhWtEIbyVkzfhNncpzMsABjqpVHOXoVmSUISxqt1pPIMwEi9WjYtI1kYCpUssdxYKLYgdjRxvzwcaKNyONJGQ5FEQLQ65VkRvwvnouz79rLE/k2Yz7f5ahPhtHgTNJbT1lzkdegNCyvLjWbpar1N7AwsNJjyJcxwbQ2dIU5dtZoVt9NKzW5ALUSNrDqSUmavW8TRTN3sFCR47haNaHdDzbvL83lPVxpP9EyeHSKh3MvRNVVRTmstxNjuK7pG/+OzFJr7oZ4Mpe66Tst7r3VvbRgSuFB4wuAFMl4gSlBAUf0AAAAASUVORK5CYII="

  return (

    <>
      <nav className="main-nav">
        
        <div className="logo">
          <h2>
            <span>I</span>ndia
            <span>C</span>ricket
          </h2>
        </div>

        <div className= {show ? "menu-link mobile-menu-link" : "menu-link"}>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">about</Link>
            </li>
            <li>
              <Link to="/service">services</Link>
            </li>
            <li>
              <Link to="/contact">contact</Link>
            </li>
          </ul>
        </div>

        <div className="social-media">
          <ul className="social-media-desktop">
            <li>
              <a
                href="https://www.cricbuzz.com/"
                target="_blank"rel="noreferrer">
                <img src={img1} alt="cricbuzz logo"className="cricbuzz" />
              </a>
            </li>
            <li>
              <a
                href="https://www.espncricinfo.com/"
                target="blank">
                <img src={img2} alt="cricinfo logo" className="espncricinfo" rel="noreferrer" />
              </a>
            </li>
            <li>
              <a
                href="https://www.mykhel.com/cricket/india-tp3/players/"
                target="blank">
               <img src={img3} alt="cricwindow logo"className="cricwindow"rel="noreferrer" />
              </a>
            </li>
          </ul>

           <div className="hamburger-menu ">
             <GiHamburgerMenu onClick={() => setShow(!show)}/>
           </div>

        </div>
      </nav>
    </>
  );
};

export default Navbar;
