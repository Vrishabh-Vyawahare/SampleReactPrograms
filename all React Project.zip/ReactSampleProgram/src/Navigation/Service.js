import Navbar from "./Navbar";

  const Service = () => {
  return (
    <>
      <Navbar />
      <div className="content-section">
        <p>Welcome to </p>
        <h1>India Cricket Service Page</h1>
      </div>
    </>
  );
};
  export default Service;
  