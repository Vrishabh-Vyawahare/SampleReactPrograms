import Navbar from "./Navbar";
 const About = () => {
  return (
    <>
      <Navbar />
      <div className="content-section">
        <p>Welcome to </p>
        <h1>India Cricket About Page</h1>
      </div>
    </>
  );
};
export default About;


  