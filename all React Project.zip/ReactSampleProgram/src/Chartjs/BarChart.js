import React from "react";
import { Bar } from 'react-chartjs-2';
import Chart from 'chart.js/auto';

function BarChart() {
    return (
      <div>
        <Bar 
        data={{
            labels:['Rohit','Virat','SKY','Hardik'],   //x axis val
            datasets:[
                {
                  label:"Total Runs in year 2022",  //graph title
                  data:[930,860,450,566], //y axis value
                  backgroundColor: ['orange','yellow','green','blue'],
                  borderColor:'black',
                  hoverBackgroundColor:'white',        
                  borderWidth:1,
                  hoverBorderWidth:3,
                  borderRadius:'10' ,   // corner border radius
                  barThickness: 80,
                  // barPercentage:0.9
                 


                }
            ]
        }}
        height={100}
        width={150}
         />
      </div>
    );
  }
  
  export default BarChart;