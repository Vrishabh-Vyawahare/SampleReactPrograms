import Navbar from "./Navbar";
import Product from "./Product";
import Cart from "./Cart";
import {useState} from 'react'

function Main() {
  const[cart,setCart]=useState([]);    // store items in cart
  const[showCart,setShowCart]=useState(false); 

  const AddToCartHandler=(value)=>{
    let ispresent=false;
    cart.forEach((val)=>{
      if(value.id===val.id){ispresent=true}    //if already present item id matched
    })
    if(ispresent){
      alert("Items already present in the cart")
    } else{
    alert("Items added to cart")
    console.log(value);
    setCart([...cart,{...value,quantity:1}])}
}

const CartNavHandler=()=>{
  setShowCart(true);
}
    return (
      <div>
      <Navbar count={cart.length} cartNav={CartNavHandler}/>  
    
      {showCart?<Cart  cart={cart} setCart={setCart}/>: <Product AddToCartHandler={AddToCartHandler}/>}     
      </div>
    );
  }
  
  export default Main;