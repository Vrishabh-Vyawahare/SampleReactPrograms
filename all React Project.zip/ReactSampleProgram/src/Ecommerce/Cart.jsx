import React,{useEffect, useState} from 'react';
 import './Cart.css'

function Cart({cart,setCart}) {

  const[totalPrice,setTotalPrice]=useState(1);
  //Incerment Quantity
  const Increment=(value)=>{
   let isShow='false'
   cart.forEach((val)=>{
     if(value.id===val.id){
      isShow='true'
      val.quantity=val.quantity + 1;
    }
      if(isShow){
      setCart([...cart])
      }
  })}
   //Decerment Quantity
  const Decrement=(value)=>{
    let isShow='false'
    cart.forEach((val)=>{
      if(value.id===val.id){
       isShow='true'
       if(val.quantity>1){val.quantity=val.quantity - 1;}
       
     }
       if(isShow){
       setCart([...cart])
       }
   })
 
 }

 //calculate Total Price
  const Total=()=>{
    let total=0;
    cart.map((value)=>{return (          
       total=total+(value.price * value.quantity))
    })
    setTotalPrice(total);
  }

  useEffect(()=>{
    Total();
  })

  //Remove item from cart
  const RemoveHandler=(value)=>{
  
    const newCart=cart.filter((val,index)=>{
      return (val.id!==value.id)
          })
         setCart([...newCart]);
        
  }
    return (
      <div>
        <table className="table table-borderless">   
      <thead>
        <tr>
          <th>Image</th>
          <th>Item Name</th>
          <th>Quantity</th>
          <th>Price</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
          {cart &&
            cart.map((value)=>(
              <tr key={value.id}>
                <td>{<img src={value.images[0]} style={{"width":"5rem"}} alt="random"/>}</td>
                <td>{value.title}</td>
                
                <td> <button onClick={()=>Decrement(value)}> - </button>
                 <span>{value.quantity}</span>
                 <button onClick={()=>Increment(value)}> + </button></td>
              
                <td>{value.price}</td>
                <td>
                <button className="btn btn-primary" onClick={()=>RemoveHandler(value)}>Remove</button>
                </td>
                </tr>
                )) 
               }
       </tbody>
       </table>
      

        <div className='grid-container'>
        <div>
        <button className='btn btn-danger'  onClick={()=>setCart([])}>Clear</button>
        </div>
        <div>
        <span><h4>Total price : {totalPrice}</h4></span>
        </div>

        <div>
        <button className='btn btn-success'>Buy</button>
        </div>
       </div>

      </div>
     
    );
  }
  
  export default Cart;