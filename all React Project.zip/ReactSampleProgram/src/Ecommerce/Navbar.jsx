import  {useNavigate,Link} from 'react-router-dom';
function Navbar({count}) {
  const navigate=useNavigate();
  
    return (
      <>
      <nav className="navbar bg-info">
      <div className="container-fluid">
      <Link className="navbar-brand" to="/"><strong>Shopify</strong></Link>
      <button className='btn btn-success' onClick={()=> navigate(`/cart`)}> Cart <sup>{count}</sup></button>
      </div>
      </nav>   
      </>
    );
  }
  
  export default Navbar;