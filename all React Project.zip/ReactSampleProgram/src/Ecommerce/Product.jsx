import {useEffect, useState} from 'react'

function Product({AddToCartHandler}) {
    const[product,setProduct]=useState([]);    //to store product items.
   
    useEffect(()=>{

        fetch('https://dummyjson.com/products')
        .then(res => res.json())
        .then((res)=>
        {
            setProduct(res.products);
        });
    },[])

    
    
    return (
        <div className='container'>
            <div className="row justify-content-center">
            {
                product && product.map((value)=>{
                return(
                    
                <div className='card' style={{"width":"18rem","height":"auto"}}>
                <img className='card-img-top' alt="Random" src={value.images[0]} style={{"width":"100%","height":"12rem"}}/>
                 <div className="card-body" key={value.id}>
                 <h4 className="card-title">{value.title}</h4>
                 <h6 className="card-subtitle">{value.category}</h6>
                 <p className="card-text">{value.description}</p>
                 <strong  className="card-text">Rs. {value.price} /-</strong><span>     
                <button onClick={()=>AddToCartHandler(value)}className='btn btn-outline-success' style={{"float":"right"}}>Add To Cart</button>
                </span>
                </div>
                 </div>
                 
                 
                 )
                }
                )
            }
        </div>
        </div>
     
    );
  }
  
  export default Product;