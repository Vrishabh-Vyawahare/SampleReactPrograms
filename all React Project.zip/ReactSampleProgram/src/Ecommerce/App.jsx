import React from "react";
import {Routes,Route} from 'react-router-dom';
import Navbar from "./Navbar";
import Product from "./Product";
import Cart from "./Cart";
import {useState} from 'react'
import 'react-toastify/dist/ReactToastify.css';
import { ToastContainer, toast } from 'react-toastify';
function App() {
    const[cart,setCart]=useState([]);
    
    const AddToCartHandler=(value)=>{
        let ispresent=false;
        cart.forEach((val)=>{
          if(value.id===val.id){ispresent=true}    //if already present item id matched
        })
        if(ispresent){
          toast.warn("Item already present in the cart",{position : "top-right",autoClose: 2000})   
        } else{
          toast.success("Item added successfully",{position : "top-right"})   
        console.log(value);
        setCart([...cart,{...value,quantity:1}])}
    }
  return (
    <>
    <Navbar count={cart.length} />
    <Routes>
      <Route path="/" element={<Product AddToCartHandler={AddToCartHandler}/>}/>
      <Route exact path="/cart" element={<Cart cart={cart} setCart={setCart}/>}/> 
    </Routes>
    <ToastContainer />
    </>
 
  );
}

export default App;

