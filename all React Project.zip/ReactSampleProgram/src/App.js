import React from "react";
import {Routes,Route} from 'react-router-dom';
import TableData from './CRUD/TableData';
import FormData from './CRUD/FormData';
import EditData from './CRUD/EditData';

function App() {
  return (
    <>
    <Routes>
      <Route path="/" element={<TableData />}/>
      <Route path="/formdata" element={<FormData />}/> 
      <Route exact path="/editdata/:empid" element={<EditData />}/> 
    </Routes>
    </>
 
  );
}

export default App;

