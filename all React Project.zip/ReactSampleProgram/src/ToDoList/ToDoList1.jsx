import React, { useState } from "react"; 
import { FcPlus } from "react-icons/fc";
import { ImCancelCircle } from "react-icons/im";
import './ToDoList1.css';

function ToDoList1() {

    const[itemname,setItemName]=useState('');
    const[listitem,setListItem]=useState([]);

    const AddItem=()=>{
     if(itemname!=="")
       { setListItem((prevItem)=>{
            return(
                [...prevItem,itemname])
        })
        setItemName("");}

        else{alert("enter a value")}
     }

     const DeleteItem=(index)=>{ 

          const newListItem=listitem.filter((val,ind)=>{
      return ind!==index;
          })
      //  const newListItem=[...listitem];
        //newListItem.splice(index,1)
       
         setListItem([...newListItem]);
        
     }

    return (
    
          <div className="main-div">

            <div className="heading" >
              <h1>To Do List</h1>
            </div>

            <div className="input-box">
            <input type="text" 
                placeholder="Enter a item name"
                onChange={(e)=> setItemName(e.target.value)}
                value={itemname}>
            </input> 
            </div>

            <div className="add-button">
            <FcPlus onClick={AddItem} />
            </div>
           
            <div className="list">
             <ol> 
                { listitem.map((value,index)=>{
                   return(
                    <li key={index} >
                    { value }  <ImCancelCircle onClick={()=>DeleteItem(index)}></ImCancelCircle>
                    </li>
                    )
                     })
                }
            </ol>
            </div>    
          </div>
    );
  }
  
  export default ToDoList1;