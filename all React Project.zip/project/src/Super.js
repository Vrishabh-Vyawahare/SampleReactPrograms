import {useContext} from 'react';

import {Info} from './App' 
function Super(){
    const{appcolor,getDay} =useContext(Info);
    const day="Sunday"
    return(
        <div>
        <h1 style={{color:appcolor}}>SuperChild Component</h1>
        <button onClick={()=>getDay(day)}>Day</button>
        
        </div>
    )
}
export default Super;