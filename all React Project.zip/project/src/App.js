import logo from './logo.svg';
import './App.css';
import {useState,createContext} from 'react';
import Childnode from './Childnode';
import Other from './Other.js'


export const Info=createContext();
function App() {
  const[color,setcolor]=useState("Red")
  const getDay=(data)=>{
    console.log(data);
  }
  return (
    <Info.Provider value={{appcolor:color,getDay:getDay}}>
     <div>
      <h1>App component</h1>
       <Childnode />
     
      {/* <Other /> */}
     </div>
    </Info.Provider>
    

  );
};

export default App;
