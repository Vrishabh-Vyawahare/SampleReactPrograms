import { Component } from "react";

class Classstate extends Component{
    constructor(){
        super();
        this.state={data:"sachin"};
    }
     update(){
        this.setState({data:"vrishabh"});
    }
    
render(){
    return(
        <div>
            <h1>{this.state.data} Hello {this.props.name}</h1>
            <button onClick={()=>this.update()}>change</button>
        </div>
    )
    }
};
export default Classstate;