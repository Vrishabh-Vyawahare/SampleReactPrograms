import {useRef} from 'react';
function Ref(){
    const inputRef=useRef()
    const get=()=>
    {
      //console.log('hello');
      //inputRef.current.focus();
      inputRef.current.value="Vrishabh";
    }
    return(
        <div>
         <input type= "text" ref={inputRef} />
         <button onClick={()=>get()}>click</button>
        </div>
    );
}
export default Ref;