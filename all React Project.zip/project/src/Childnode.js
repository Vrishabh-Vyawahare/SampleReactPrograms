import {useContext} from 'react';
import {Info} from './App' 
import Super from './Super';
function Childnode(){
    const{appcolor} =useContext(Info);
    return(
        <div>
        <h1 style={{color:appcolor}}>Child Node Component</h1>
      <Super />
        </div>
    )
}
export default Childnode;