import {useContext} from 'react';
import {Info} from './App' 
function Other(){
    const{appcolor} =useContext(Info);
    return(
        <div>
        <h1 style={{color:appcolor}}>Other Component</h1>
        </div>
    )
}
export default Other;