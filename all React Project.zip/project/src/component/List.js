function List(){
    const Array1=['Vrishabh','Rahul','Rohit']
    
    return(
    <div>
        {
          Array1.map(names =><h2>{names}</h2>)
        }
    
    </div>)
    
};
export default List;