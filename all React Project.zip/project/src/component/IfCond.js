import {useState} from 'react';
function IfCond()
{   
    const[data,setData]=useState(2);
      return(
        <div>
            {data===1?<h1>value is 1</h1>:data===2?<h1>value is 2</h1>:<h1>value is 3</h1>}
        </div>
    );
}
export default IfCond;