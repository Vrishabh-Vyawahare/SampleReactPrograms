function ListObj(){
    const person=
    [
        {
            id:3,
            name:'Vrishabh',
            age:25
        },
        
       {
            id:2,
            name:'Rahul',
            age:28
        },
        {
            id:1, 
            name:'Rohit',
            age:35
        }
    ]
    const PersonList =person.map(persons =><h2  key={persons.id}>I am {persons.name}.I am {persons.age} years old</h2>)
    return(
    <div>
        {PersonList}
    </div>
    );
    
};
export default ListObj;