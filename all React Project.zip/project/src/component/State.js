import {useState} from 'react';
function State()
{   
    const[data,setData]=useState("sachin");
      return(
        <div>
            <h1>{data}</h1>
            <button onClick={()=>setData("Tendulkar")}>change</button>
        </div>
    );
}
export default State;