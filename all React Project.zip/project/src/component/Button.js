import {useState} from 'react';
function Button()
{   
    const[status,setStatus]=useState(false);
      return(
        <div>
            {
                status? <h1>hello</h1>:null
            }
             <button onClick={()=>setStatus(false)}>Hide</button>
             <button onClick={()=>setStatus(true)}>Show</button>
             <button onClick={()=>setStatus(!status)}>Toggle</button>
             </div>
            
    );
}
export default Button;