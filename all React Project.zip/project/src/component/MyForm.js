import { useState } from 'react';
function MyForm() {
  const [name, setName] = useState("");

  function handleSubmit (e){
    e.preventDefault();
  }

  return (
    <form onSubmit={handleSubmit}>
      <label>Enter your name:
        <input type="text"onChange={(e) => setName(e.target.value)}
        />
      </label>
      <button type="submit">Submit</button>
    </form>
  )
}
export default MyForm;