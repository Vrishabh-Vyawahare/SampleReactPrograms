import {useReducer} from 'react'
const initialstate=0;
const reducer=(state,action)=>{
    switch(action){
        case 'Inc':
            return state+1;
        case 'Dec':
            return state-1;
        case 'Reset':
            return initialstate;
        Default:
        return state;
    
    }
}
function UseReducerHook(){
    const[count,dispatch]=useReducer(reducer,initialstate)
    return(
        <div>
         <h1> count={count}</h1>
         <button onClick={()=>dispatch('Inc')}>Inc</button>
         <button onClick={()=>dispatch('Dec')}>Dec</button>
         <button onClick={()=>dispatch('Reset')}>Reset</button>
        </div>
    )
}
export default UseReducerHook;