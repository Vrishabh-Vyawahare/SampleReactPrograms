import react from 'react';
import {useState} from 'react';
import styles from './user.module.css';
function User(){
    const[enterName,setName]=useState(''); 
    const[enterAge,setAge]=useState(''); 

    const submitHandler=(event)=>
    {
      event.preventDefault();
      
      if(enterName.trim().length==0||enterAge.trim().length==0)
      {
          return;
      }
      if(+enterAge<1)
      {
         return;
      }
      console.log(enterName,enterAge); 
      setName('');
      setAge('');
    }

    const usernameHandler=(event)=>
    {
      setName(event.target.value);
    }
    const ageHandler=(event)=>
    {
      setAge(event.target.value);
    }
   
    return(
        <div>
            <form className={styles.form}onSubmit={submitHandler}>
                <label className={styles.label}>Username</label>
                <input type="text"
                value= {enterName}
                onChange={usernameHandler}/><br></br>
                <label className={styles.label}>Age</label>
                <input type="number" 
                value={enterAge} 
                onChange={ageHandler}/><br></br>
                <button className={styles.button}type="Add User">Submit</button>
            </form>
        </div>
    );
};
export default User;