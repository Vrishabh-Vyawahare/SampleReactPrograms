import{useRef} from'react'
import FRChild from './FRChild';

function ForwardRef(){
    const InputRef=useRef();
    const get=()=>{
        InputRef.current.value='vrishabh';
    }
    return(
        <div>
            <h1>forward Ref</h1>
            <FRChild ref={InputRef}/>
            <button onClick={()=>get()}>Update</button>
        </div>

    );

}
export default ForwardRef;