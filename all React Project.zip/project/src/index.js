import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import User from './component/User.js';
import Child from './Child';
import State from './component/State.js';
import Button from './component/Button.js';
import MyForm from './component/MyForm.js';
import IfCond from './component/IfCond.js';
import Fragment from'./component/Fragment.js';
import List from'./component/List.js';
import ListObj from'./component/ListObj.js';
import Hook from  './component/Hook.js';
import UseReducerHook from  './component/UseReducerHook.js';
import Ref from './Ref.js';
import ForwardRef from './ForwardRef.js'
import Classstate from './Classstate.js'

function parent(data){
  alert(data);
}
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
    {/* <Ref /> */}
    {/* <ForwardRef /> */}
    {/* <Button /> */}
    {/* <Classstate  name="bunty"/> */}
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
