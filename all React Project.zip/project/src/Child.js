function Child(props){
    const data="Vrishabh";
return(
    <div>
        <button onClick={()=>props.alert(data)}>click me</button>
    </div>
)
};
export default Child;