import { createStore } from 'redux'
import Reducer from './Reducer';
import Reducer2 from './Reducer2';

import { combineReducers } from 'redux'

const store = createStore(combineReducers({Reducer,Reducer2}));


export default store;
