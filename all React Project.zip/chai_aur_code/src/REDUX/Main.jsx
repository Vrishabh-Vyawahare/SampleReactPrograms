import { useSelector,useDispatch } from 'react-redux';

function Main() {

  const value = useSelector((state) => state.Reducer.number);
  const value2 = useSelector((state) => state.Reducer2.number2);
 
  const dispatch = useDispatch();

  return (
    <div>
      
      <h1>{value}</h1>
      <h1>{value2}</h1>
      <button onClick={()=>{dispatch({ type: 'INCREMENT' })}}>Increment</button>
      <button onClick={()=>{dispatch({ type: 'DECREMENT' })}}>Decrement</button>
    
    </div>
  );
}

export default Main;