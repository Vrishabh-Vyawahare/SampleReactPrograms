import React, { useState } from "react";

const Newlist = () => {
  const [country, setCountry] = useState("");
  const [State, setState] = useState("");

  const fetchData =() => {
    axios.get("http://localhost:3000/states")
    .then(res => {
      setCountry(data.countries[0].name);
      setCity(data.countries[0].states[0]);
    })
   
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleCountryChange = (e) => {
    setCountry(e.target.value);

    const states = data.countries.find((c) => c.name === country).states;

  
    setCity(states[0]);
  };

  const handleStateChange = (e) => {
    setCity(e.target.value);
  };

  return (
    <div>
      <select
        value={country}
        onChange={handleCountryChange}
      >
        {data.countries.map((country) => (
          <option key={country.name} value={country.name}>
            {country.name}
          </option>
        ))}
      </select>

      <select
        value={State}
        onChange={handleStateChange}
      >
        {data.countries
          .find((c) => c.name === country)
          .states.map((city) => (
            <option key={state} value={state}>
              {state}
            </option>
          ))}
      </select>
    </div>
  );
};

export default Newlist;