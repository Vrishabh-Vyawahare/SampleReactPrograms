import Menu from "./Pages/Menu";
//import ShowChart from './ShowChart'
import DropdownList from'./DropDownList/DropdownList'

function View() {

  return (
   <>
  <Menu />
  <DropdownList />
  {/* <ShowChart /> */}
   </> 
  );
}

export default View;