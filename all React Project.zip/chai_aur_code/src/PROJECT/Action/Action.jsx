export const BJP = {
    type: 'IND',
  };
  export const INC = {
    type: 'USA',
  };
  export const TMC = {
    type: 'EUR',
  };

  
  

