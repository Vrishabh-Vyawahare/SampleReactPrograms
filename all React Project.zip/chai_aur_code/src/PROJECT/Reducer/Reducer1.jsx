const initialState={
    show:true
  }
  
  const Reducer1 = (state=initialState, action) => {
      
    switch(action.type){
       case 'IND':
        return{
        ...state,
        show:state.show,
       };
     
       default:
        return state;
    }
  
    };
    export default Reducer1;