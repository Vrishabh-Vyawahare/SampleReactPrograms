const initialState={
    number2:0
  }
  
  const Reducer2 = (state=initialState, action) => {
      
    switch(action.type){
       case 'USA':
        return{
        ...state,
        number2: state.number2 - 1,
       };
     
       default:
        return state;
    }
  
    };
    export default Reducer2;