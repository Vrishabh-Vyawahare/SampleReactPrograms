import React from 'react';
import {Route, Routes,BrowserRouter as Router } from 'react-router-dom';
import USA from "./USA"; 
import Europe from "./Europe"; 
import SideBar from '../Sidebar/Sidebar';
import India from './India';
const Menu = () => {    
    return ( 
      <> 
        <Router>
        <SideBar />
        <Routes>  
                <Route exact path='/' element={<India />} ></Route>
                <Route  path='/usa' element={<USA />}></Route>
                <Route  path='/europe' element={<Europe/>} ></Route>
        </Routes>
        </Router>    
      </> 
    ); 
  }; 
    
  export default Menu;