import { useDispatch,useSelector } from "react-redux";
import { useEffect } from "react";

const USA = () => {
    const value = useSelector((state) => state.Reducer2.number2);
    const dispatch=useDispatch()
   useEffect(()=>{dispatch({ type: 'USA' })},[])
    return ( 
   <>
      <h1>{value}</h1>
   </>
    ); 
  }; 
    
   
  export default USA