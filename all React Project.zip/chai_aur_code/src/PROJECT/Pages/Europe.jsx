import { useDispatch,useSelector} from "react-redux";
import { useEffect } from "react";
const Europe = () => {
    const value = useSelector((state) => state.Reducer3.number3);
const dispatch=useDispatch()
useEffect(()=>{dispatch({ type: 'EUR' })},[])
    return ( 
   <>
      <h1>{value}</h1>
   </>
    ); 
  }; 
    
   
  export default Europe