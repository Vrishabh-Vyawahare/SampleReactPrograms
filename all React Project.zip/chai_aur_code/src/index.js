import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './PROJECT/App';
// import App from './REDUX/App';
//import BgChanger from './backgroundChanger/BgChanger';



const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
 <>
{/* <App /> */}
<App />
{/* <Dropdownlist /> */}
 </>
);

