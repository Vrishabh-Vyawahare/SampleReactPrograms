import React from 'react'
import UseMemoHook from './useMemoHook/UseMemoHook';
// import Counter1 from './HOC Demo/Counter1';
// import Counter2 from './HOC Demo/Counter2';

function App() {
  return (
    <div> 
      {/* <Counter1 name1={"onClick event"}/>
      <Counter2 name2={"onMouseOver event"} /> */}
      <UseMemoHook/>
    </div>
  );
}

export default App;