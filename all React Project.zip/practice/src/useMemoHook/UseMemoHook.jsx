import React, { useMemo, useState } from 'react'

function UseMemoHook() {
    const[num,setnum]=useState(0);
    const[num2,setnum2]=useState(100);

   const multiply=useMemo(
     function multiplication(){
    console.log("multiplication is calculated");
    return  num * 10;
   },[num])

  // function multiplication(){
  //     console.log("multiplication is calculated");
  //     return  num * 10;
  //     }

  return (
    <div> 
    <h2> Addition is {num}</h2>
    <h3>multiplication is {multiply}</h3>
    <button onClick={()=>setnum(num+10)}> ADD</button>
    <h2> Substraction is {num2}</h2>
    <button onClick={()=>setnum2(num2 - 10)}>Minus</button>
    </div>
  );
}

export default UseMemoHook;