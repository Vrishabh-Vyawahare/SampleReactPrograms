import React from 'react'
import HOCComp from './HOCComp';

function Counter1(props) {

  return (
    <div> 
        <button onClick={props.Increment}>{props.name1}</button>
    </div>
  );
}

export default HOCComp(Counter1);