import React, { useState }  from 'react'

const HOCComp=(WrappedComp)=> {
 const NewComponent=(props)=>{
    const[num,setNum]=useState(0);
    const Increment =()=>{
        setNum(num=>num+1);
    }
  return(
    <div> 
    {num}
    <WrappedComp  Increment={Increment} {...props}/>
    </div>
  )
 }

return NewComponent;
}

export default HOCComp;