import React  from 'react'
import HOCComp from './HOCComp';

function Counter2(props) {

return (
  <div> 
      <button onMouseOver={props.Increment}>{props.name2}</button>
  </div>
);
}

export default HOCComp(Counter2);