import React from 'react';
function AddPhoto(){
        return(
            <div>
                <h1>Photowall</h1>
                <form className='form'>
                    <input type='text' placeholder='link'></input>
                    <input type='text' placeholder='description'></input>
                    <button>Post</button>
                </form>
             </div> 
        )
    }

export default AddPhoto;