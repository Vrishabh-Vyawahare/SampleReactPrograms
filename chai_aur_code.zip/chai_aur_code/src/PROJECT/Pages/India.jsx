
import { useEffect, useState } from "react";
import { useDispatch,useSelector} from "react-redux";
import ShowChart from "../ShowChart";
import SideBar from "../Sidebar/Sidebar";


const India = () => {
const value = useSelector((state) => state.Reducer1.show);


const dispatch=useDispatch()

useEffect(()=>{
  dispatch({ type: 'IND' });
},[])

    return (   
   <>
     
      {value?<ShowChart />:<SideBar />}
   </>
    ); 
  }; 
    
   
  export default India