const initialState={
    number3:0
  }
  
  const Reducer3 = (state=initialState, action) => {
      
    switch(action.type){
       case 'EUR':
        return{
        ...state,
        number3: state.number3 * 1,
       };
     
       default:
        return state;
    }
  
    };
    export default Reducer3;