import React from 'react'
import {FaHome,FaTasks,FaUserAlt  } from "react-icons/fa";

export const SidebarIcon = [
    {
        title: 'INDIA',
        path: '/',
        icon: <FaHome />
    },
    {
        title: 'USA',
        path: '/USA',
        icon: <FaTasks />
    },
    {
        title: 'Europe',
        path: '/Europe',
        icon: < FaUserAlt/>
    },
    
]