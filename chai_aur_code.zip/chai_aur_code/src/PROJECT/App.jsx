import React from 'react';
import { Provider } from 'react-redux';
import store from './Store/Store';
import View from './View';

function App(){
  return(
<Provider store={store}>
 <View />
</Provider>
  )
}

export default App;