import { createStore } from 'redux'
import Reducer1 from '../Reducer/Reducer1';
import Reducer2 from '../Reducer/Reducer2';
import Reducer3 from '../Reducer/Reducer3';


import { combineReducers } from 'redux'

const store = createStore(combineReducers({Reducer1,Reducer2,Reducer3}));


export default store;