export const data = [
    {
      country: "India",
      states: [
        {
          state: "Maharashtra",
          cities: [{ name:"Mumbai"}, { name:"Pune"}]
        },
        {
          state: "UttarPradesh",
          cities: [{ name:"Varanasi"}, { name:"Noida"}]
        }
      ],
    },
    {
      country: "United States",
      states: [
        {
          state: "California",
          cities: [{ name:"Los Angeles"}, { name:" San Francisco"}]
        },
        {
          state: "Texas",
          cities: [{ name:"Dallas"}, { name:"Austin"}]

        }
      ],
    },
  ];