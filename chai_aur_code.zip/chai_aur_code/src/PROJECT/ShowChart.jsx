import axios from 'axios';
import React, { useState, useEffect } from 'react'
import 'chart.js/auto';
import { Chart } from 'react-chartjs-2';
 
 
const ShowChart = () => {
    const [data, setData]  = useState([]);
    const [type,setType]=useState('bar')

    function changeChartType(val){
        setType(val);
    }
   
    function getChartData() {
        axios.get("http://localhost:3000/states")
            .then(res => {
                console.log(res.data);
                setData(res.data)
            })
            .catch(err => {
                console.log(err);
            });
 
           
    }
    useEffect(() => {
        getChartData();
      }, []);

      var data1 = {
        labels:data.map((val)=>val.name),
        datasets: [{
          label: 'My First Dataset',
          data:data.map((val)=>val.patient),
          backgroundColor:['maroon','olive','magenta','orangered'],
          borderColor: 'black',
          borderWidth: 1,
          barThickness:50
  }]
};
const options={
    scales: {
        y: {
            beginAtZero: true,
        },
},
};
 
      return(
          <div>
              <h1>Bar Chart</h1>
              <button onClick={()=>changeChartType('line')}>Line Chart</button>
              <button onClick={()=>changeChartType('pie')}>Pie Chart</button>
              <button onClick={()=>changeChartType('bar')}>Bar Chart</button>
              <div>
                  <Chart
                    type={type}
                    data={data1}
                    options={options}
                  />
              </div>
          </div>
      )
}
 
export default ShowChart;