import {useState} from 'react'
import './BgChanger.css'
function BgChanger() {
  const [color,setColor]=useState('black')
  return (
    <div className="main-div"style={{backgroundColor:color}}>
      <div>
        <button onClick={()=>setColor('red')}>RED</button>
        <button onClick={()=>setColor('green')}>green</button>
        <button onClick={()=>setColor('orange')}>orange</button>

      </div> 
    </div>
  );
}

export default BgChanger;
