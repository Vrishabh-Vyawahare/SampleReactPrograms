import React,{useState} from 'react';

const Form=()=>{

    const[fname,setFname]=useState();
    const[lname,setLname]=useState();

    const[showFName,setShowFName]=useState();
    const[showLName,setShowLName]=useState();

    const InputEvent1=(e)=>{
        setFname(e.target.value);
    }
    const InputEvent2=(e)=>{
        setLname(e.target.value);
    }
    const Submit=(e)=>{
        e.preventDefault();
        setShowFName(fname);
        setShowLName(lname);
    }
    
    return(
        <>
        <form onSubmit={Submit}>
        <div>
            <h1>Hello {showFName} {showLName}</h1>

            <input 
            type='text'
            placeholder='Enter First Name'
            onChange={InputEvent1}
            value={fname}
            />   
            <br />

            <input 
            type='text'
            placeholder='Enter Last Name'
            onChange={InputEvent2}
            value={lname}
            />
            <br />

            <button type='Submit'>Submit</button>
        </div>
        </form>
        </>

    )
}
export default Form;