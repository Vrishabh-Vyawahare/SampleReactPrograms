import React from 'react';

const CircuitEval=()=>{
    const[Demo,setDemo]=React.useState("Vyawahare"); 
    return(
        <>
       {/* <h1>{ Demo || " Vrishabh "}</h1>  */}
       <h1>{ Demo && " Vrishabh "}</h1> 
        </>
    );
};
export default CircuitEval; 