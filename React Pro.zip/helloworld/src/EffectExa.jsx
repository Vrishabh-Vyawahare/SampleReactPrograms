import React,{useState,useEffect} from 'react';

const EffectExa=()=>{
    const[num,setNum]=useState(0);
    useEffect(()=>{
       // alert(`you clicked ${num} times`);
       document.title=`you clicked ${num} times`;
    },[num])
    return(
        <div>
            <h1>{num}</h1>
            <button onClick={()=>{setNum(num+1)}}> Click Me</button>
        </div>

    )
}
export default EffectExa;