import React from 'react';
import Newapp from './Newapp';
import Data from './Data';
function Newapp2(){
    return(
     <>
    {Data.map((val)=>
    {return <Newapp 
        //key={val.id}
        imgsrc={val.imgsrc}
        altname={val.altname}
        link={val.link}
        name={val.name}/>})}
    {/* <Newapp 
    imgsrc={Data[0].imgsrc}
    altname={Data[0].altname}
    link={Data[0].link}
    name={Data[0].name}/>

    <Newapp 
    imgsrc={Data[1].imgsrc}
    altname={Data[1].altname}
    link={Data[1].link}
    name={Data[1].name}/>

    <Newapp 
    imgsrc={Data[2].imgsrc}
    altname={Data[2].altname}
    link={Data[2].link}
    name={Data[2].name}/>

    <Newapp 
    imgsrc={Data[3].imgsrc}
    altname={Data[3].altname}
    link={Data[3].link}
    name={Data[3].name}/>
  */}
     </>
    )
}
export default Newapp2;