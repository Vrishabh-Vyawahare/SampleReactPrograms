import React,{Component} from 'react';
class ClassEx extends Component 
{
    render(){
        return(
            <h2>React JavaScript</h2>
        )
    }
}
export default ClassEx;
