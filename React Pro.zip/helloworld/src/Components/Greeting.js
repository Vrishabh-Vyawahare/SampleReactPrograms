import React from 'react';
function Greeting(){
    return(
    <h1>Hello vrishabh</h1>
    )
}
//const Greeting =()=><h1>Hello Vrishabh</h1>   Arrow function
export default Greeting;