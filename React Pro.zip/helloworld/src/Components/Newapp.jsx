import React from 'react';
function Newapp(props){
    return(
     <>
    <div>
        <img src={props.imgsrc} alt={props.altname}/>
    <div>
    <h1> {props.name}</h1>
    <a href={props.link} target='_blank' >
    <button>View Details</button>
    </a>
    </div>
    </div>
    
     </>
    )
}
export default Newapp;