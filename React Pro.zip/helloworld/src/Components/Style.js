import React from 'react';
import './Style.css'
const img1="https://picsum.photos/200/300";
const img2="https://picsum.photos/250/300";
const img3="https://picsum.photos/300/300";
const glink="https://www.google.com/"

function Style() {
    return (
      <>
       <h1 className='heading' contentEditable='true'>Welcome to Art Gallery</h1>
       <div className='img_div'>
       <img src={img1} alt="Random "/>
       <img src={img2} alt="Random "/>
       <a href={glink} target='_blank'>
       <img src={img3} alt="Random "/>
       </a>
       </div>
      </>
    );
  }
  
  export default Style;