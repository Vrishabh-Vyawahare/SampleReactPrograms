const Data = [   
{
//id:1,
imgsrc:'https://www.cricbuzz.com/a/img/v1/152x152/i1/c332891/virat-kohli.jpg',
altname:'Virat kohli',
link:'https://www.cricbuzz.com/profiles/1413/virat-kohli',
name:'Virat Kohli'
},
 
{
//id:2,
imgsrc:'https://www.cricbuzz.com/a/img/v1/152x152/i1/c170942/joe-root.jpg',
altname:'Joe root',
link:'https://www.cricbuzz.com/profiles/8019/joe-root',
name:'Joe Root'
},

{
// id:3,
imgsrc:'https://www.cricbuzz.com/a/img/v1/152x152/i1/c332907/steven-smith.jpg',
altname:'Steve Smith',
link:'cricbuzz.com/profiles/2250/steven-smith',
name:'Steve Smith'
},

{
//id:4,   
imgsrc:'https://www.cricbuzz.com/a/img/v1/152x152/i1/c244826/kane-williamson.jpg',
altname:'Kane Wiiliamson',
link:'https://www.cricbuzz.com/profiles/6326/kane-williamson',
name:'Kane Wiiliamson'
}];

export default Data;