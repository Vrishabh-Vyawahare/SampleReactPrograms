import React,{useState} from 'react';
const PlayerInfo=[
    {
        id:1,
        name:'Rohit',
        Jnum:45
    },
    {
        id:2,
        name:'Virat',
        Jnum:18
    },
    {
        id:3,
        name:'Mahi',
        Jnum:7
    }
];


const UseStateArray=()=>{

    const[data,setdata]=useState(PlayerInfo);

    const ClearArray=()=>{
        setdata([]);
    }
    
    return(
        <>
        {data.map((d)=>{return <h1>Player name:{d.name} & Jersy Number:{d.Jnum}</h1>})}
        <button onClick={ClearArray}>Clear</button>
        </>

    )
}
export default UseStateArray; 