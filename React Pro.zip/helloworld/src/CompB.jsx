//Context API use Consumer
import {firstname,lastname} from './CompA'

function CompB() {
    return (
      <firstname.Consumer>{(fname)=>{
          return(
              <lastname.Consumer>{(lname)=>{
                  return(
                      <h1>My name is {fname} {lname}</h1>
                  )
              }
            }       
              </lastname.Consumer>
          )

      }}</firstname.Consumer>
    );
  }
  
  export default CompB;
