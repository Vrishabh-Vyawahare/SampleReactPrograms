import React,{useState} from 'react';
import { BiPlus}  from "react-icons/bi";

const IncDec=()=>{

    const[num,setNum]=useState(0);
    

    const Increment=()=>{
        setNum(num+1);
    }
    const Decrement=()=>{
        num>0?setNum(num-1):setNum(0);
    }
    
    return(
        <>
        <div>
            <h1>{num}</h1>
            <button onClick={Increment}><BiPlus/></button>
            <button onClick={Decrement}>Dec</button>

        </div>
        </>

    )
}
export default IncDec;