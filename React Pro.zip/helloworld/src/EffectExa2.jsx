import React,{useState,useEffect} from 'react';

import UseRef from './UseRef1';
 

const EffectExa2=()=>{
    const[num,setNum]=useState(window.screen.width);
    const changeSize=()=>{
    setNum(window.innerWidth);
    }
    useEffect(()=>{
        console.log('addevent');
        window.addEventListener('resize',changeSize);
        return ()=>{
            console.log('removeevent');
            window.removeEventListener('resize',changeSize)
        }
       
    })
    return(
        <div>
            <h1>{num} </h1>
            
            <UseRef />
        </div>

    )
}
export default EffectExa2;