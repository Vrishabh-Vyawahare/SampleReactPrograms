
//import ClassEx from './Components/ClassEx';
//import Greeting from './Components/Greeting';
//import Style from './Components/Style';
import Newapp2 from "./Components/Newapp2";

function App() {
  return (
    <div>
       <h1>Fab 4 of Cricket</h1>
      {/* <Greeting />
      <ClassEx />
      <Style /> */}
     <Newapp2 />
    </div>
  );
}

export default App;
