import React, {useRef}from 'react'
import Child from './Child'
function Parent() {
     const reference=useRef(0)
    const InputUpdate=()=>{
        reference.current.value='Vrishabh';
      reference.current.style.color='Red'
    }
    return (
        <>
        <Child ref={reference}/>
        <button onClick={InputUpdate}>update</button>
        </>
    );
  }
  
  export default Parent;