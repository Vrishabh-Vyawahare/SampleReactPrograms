import React,{useState} from 'react';

const Digilock=()=>{

let time= new Date().toLocaleTimeString();

const[ctime,setctime]=useState(time);

const Update=()=>{
    time= new Date().toLocaleTimeString();
    setctime(time);
}
setInterval(Update,1000);
    return(
        <>
        <h1>{ctime}</h1>
        {/* <button onClick={Update}>Click</button> */}
        </>
    )
}
export default Digilock;