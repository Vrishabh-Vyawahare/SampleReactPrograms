import React from 'react';
import { useState,useEffect } from 'react';

const url = 'https://jsonplaceholder.typicode.com/users';

const FetchExa1=()=> {
    const [data, setData] = useState([])
    const FetchInfo = () => { 
        return fetch(url) 
                .then((res) => res.json()) 
                .then((dt) => setData(dt)) 
        }
        
        useEffect(() => {
            FetchInfo();
        }, [])
    return(
        <div>
            <h1>Fetch Data using JavaScript inbuilt FETCH API</h1>
            {data.map((d)=>{return <p><ul><li key={d.id}>name:{d.name} <br />username:{d.username} <br />email:{d.email}</li></ul></p>})}
        </div>
    )
}
  export default FetchExa1