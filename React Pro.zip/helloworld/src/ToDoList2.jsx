import React from 'react';
import { BiXCircle } from "react-icons/bi";
const ToDoList2=(props)=>{
 

    return(
        <>
        <div>
         <li>{props.value}</li> 
         <BiXCircle />
         </div>
        </>
    );
};
export default ToDoList2; 