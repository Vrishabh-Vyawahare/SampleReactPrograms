import React from 'react';
export default class State extends React.Component {
    constructor(){
        super();
        this.state={
            data:"Vrishabh"
        }
    }
        UpdateEvent=()=>{
          this.setState({data:"Vrishabh Vyawahare"})
        }
    
    render() {
      return <>
      <h3>My full Name is {this.state.data} </h3>
      <br />
      <button onClick={this.UpdateEvent}>Click Me</button>
      </>
    }
  }