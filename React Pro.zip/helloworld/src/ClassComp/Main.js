import React from 'react';
import Props from './Props'
import State from './State'


export default class Main extends React.Component {
    render() {
      return <>
      <h2>Hello</h2>
      <Props name="Vrishabh"/>
      <State />
      </>
    }
  }