import React from 'react' ;
export default class Props extends React.Component {
    render() {
      return <h2>I am {this.props.name}</h2>;
    }
  }