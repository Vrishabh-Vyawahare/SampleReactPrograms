import React from 'react';
import axios from 'axios'
import { useState,useEffect } from 'react';

const url = 'https://jsonplaceholder.typicode.com/users';

const AsyncExa=()=> {
    const [data, setData] = useState([]);
  const fetchInfo =
        async () => {
            const response = await axios.get(url);
            setData(response.data);
        }
        
      useEffect(() => {
        fetchInfo();
      }, []);
    
    return(
        <div>
            <h1>Fetch Data using Axios</h1>
            {data.map((d)=>{return<h5>{d.email}</h5>})}
        </div>
    )
}
  export default AsyncExa;