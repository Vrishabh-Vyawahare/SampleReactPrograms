import React from 'react';
import ToDoList2 from './ToDoList2';
const ToDoList1=()=>{

   const[name,setName]=React.useState();   //hold input value
   const[List,setList]=React.useState([]);   //hold list of input
   
   const EventChange=(e)=>{
    setName(e.target.value);
    }
    const GetItem=()=>{
        setList((obj)=>{return[...obj,name]});    ///return current array with new value
        setName('') ;     
     }

    return(
        <>
        <h1>To Do List</h1>
        <br />
        <input type ='text' placeholder='add an item' onChange={EventChange} value={name}/>
        <button onClick={GetItem}> + </button>
        <br />
        
        <ol>
        {List.map((l,i)=>{
            return <ToDoList2 
            value={l}
           // deleteid={i}
            key={i}
           // onselect={}
            />})}
        </ol>
        </>

    )
}
export default ToDoList1; 