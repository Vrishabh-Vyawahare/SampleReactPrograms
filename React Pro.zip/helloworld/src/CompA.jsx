import {createContext} from 'react'
import CompB from './CompB';
import CompC from './CompC';

const firstname=createContext();
const lastname=createContext();

function CompA() {
    return (
      <firstname.Provider value={'Vrishabh'}>
          <lastname.Provider value={'Vyawahare'}>
              <CompB />
              <CompC />
          </lastname.Provider>
      </firstname.Provider>
    );
  }
  
  export default CompA;
  export {firstname,lastname};