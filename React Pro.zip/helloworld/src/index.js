import React from 'react';
import ReactDOM from 'react-dom/client';
// import AsyncExa from './AsyncExa';
// import Parent from './Parent';
// import AxiosExa from './AxiosExa';
// import Main from './ClassComp/Main';
//import FetchExa1 from './FetchExa1';

// import Toastify from './Toastify';
// import Search from './ImageSearch/Search';
// import UseReducer1 from './UseReducer1';
//import UseRef from './UseRef1';
//import EffectExa2 from './EffectExa2';
// import LoginForm from './LoginForm';
// import App from './App';
//import Digilock from './Digilock';
// import Event from './Event';
//import Form from './Form';
// import IncDec from './IncDec'
// import CompA from './CompA';
//  import EffectExa from './EffectExa'
import Main from './RouterPro/Main';
//import UseStateArray from './UseStateArray';
// import ToDoList1 from './ToDoList1';
// import CircuitEval from './CircuitEval';
// import store from './Redux/Store';
// import {Provider} from 'react-redux';
// import ReduxApp from './Redux/ReduxApp';

const root = ReactDOM.createRoot(document.getElementById('root'));

//store.subscribe(()=>(console.log(store.getState())))
root.render(
<>
    {/* <App /> */}
    {/* <Digilock /> */}
    {/* <Event /> */}
    {/* <Form /> */}
    {/* <IncDec /> */}
    {/* <CompA /> */}
    {/* <EffectExa /> */}
    <Main />
    {/* <UseStateArray /> */}
    {/* <ToDoList1 /> */}
    {/* <CircuitEval /> */}
    {/* <LoginForm /> */}
    {/* <EffectExa2 /> */}
    {/* <UseRef /> */}
    {/* <UseReducer1 /> */}
    {/* <Search /> */}
    {/* <Toastify /> */}
    {/* <Main /> */}
    {/* <FetchExa1 /> */}
    {/* <AxiosExa /> */}
    {/* <AsyncExa /> */}
    {/* <Parent /> */}

{/* <Provider>
    <ReduxApp store={store}/>
</Provider> */}
 </>
);

