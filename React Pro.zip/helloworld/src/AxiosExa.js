import React from 'react';
import axios from 'axios'
import { useState,useEffect } from 'react';

const url = 'https://jsonplaceholder.typicode.com/users';

const AxiosExa=()=> {
    const [data, setData] = useState([]);
    const fetchInfo = () => {
        return axios.get(url).then((res) => setData(res.data));
      };
    
      useEffect(() => {
        fetchInfo();
      }, []);
    
    return(
        <div>
            <h1>Fetch Data using Axios</h1>
            {data.map((d)=>{return<h5>{d.username}</h5>})}
        </div>
    )
}
  export default AxiosExa;