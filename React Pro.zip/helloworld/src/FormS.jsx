import React,{useState} from 'react';

const FormS=()=>{

    const[fullName,setFullName]=useState(
        {
            fname:"",
            lname:""
        }
    );

    const InputEvent=(e)=>{
        const{name,value}=e.target;
        setFullName((obj)=>{
            return{
                ...obj,
                [name]:value
            }
        });
    };
    
    const Submit=(e)=>{
        e.preventDefault();
    }
    
    return(
        <>
        <form onSubmit={Submit}>
        <div>
            <h1>Hello {fullName.fname}{fullName.lname}</h1>

            <input 
            type='text'
            placeholder='Enter First Name'
            name='fname'          //fetching name attr
            onChange={InputEvent}
            value={fullName.fname}/>   
            <br />

            <input type='text'
            placeholder='Enter Last Name'
            name='lname'
            onChange={InputEvent}
            value={fullName.lname}/>
            <br />

            <button type='Submit'>Submit</button>
        </div>
        </form>
        </>

    )
}
export default FormS;