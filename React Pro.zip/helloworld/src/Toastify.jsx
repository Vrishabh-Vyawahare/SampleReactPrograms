import React from 'react';

  import { ToastContainer, toast } from 'react-toastify';
  import 'react-toastify/dist/ReactToastify.css';
  
  function Toastify(){
    const notify = (status) => {
      if(status === 'success')
        toast.success("Wow so easy!",{position : "top-center",theme: "colored"})  
      else
      toast.error("Error!",{position : "top-center",theme: "colored"})
    }

    return (
      <div>
        <button onClick={()=>notify('e')}>Notify!</button>
        <ToastContainer />
      </div>
    );
  }
  export default Toastify;