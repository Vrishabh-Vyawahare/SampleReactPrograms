import React,{useState} from 'react';

const LoginForm=()=>{
    const[email, setEmail]=useState();
    const[password, setPassword]=useState();
    const[data, setData]=useState([]);
    const Submit=(e)=>{
        e.preventDefault();
        if(email && password)
    {
        const newData= { id:new Date().getTime().toString(),email:email,password:password}
        setData([...data,newData]);     
        setEmail('');
        setPassword('');
    }
        else {alert('Please fill the Email and password details')}
    }
    return(
        <>
        <form onSubmit={Submit}>
        <div>
       <label>Email</label><br />
       <input type='text' onChange={(e)=>setEmail(e.target.value)}  autoComplete="off"  value={email}/>   
       </div>
       <br />
       <div>
       <label>Password</label><br />
       <input type='password' onChange={(e)=>setPassword(e.target.value)} autoComplete="off" value={password}/>
       </div><br />
       <div>
           <button type='Submit'>Login</button>
       </div>
       </form>
       <div>
          
           {data.map((val)=>{
                const{id,email,password} = val;
                return(
               <div  key={id}>
               <p>{email}</p>
               <p>{password}</p>
               </div>
               )})}
       </div>
        </>
    );
};
export default LoginForm; 