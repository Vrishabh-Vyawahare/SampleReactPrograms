import { BrowserRouter } from 'react-router-dom';
import Home from './Home';


function Main() {
    return (
        <BrowserRouter>
        <Home />
        </BrowserRouter>
    )
}

export default Main;