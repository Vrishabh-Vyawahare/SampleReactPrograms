import React from 'react';
import {Route, Routes } from 'react-router-dom';
import About from './About';
import Contact from './Contact';
import Error from './Error'
function Home() {
    return (
        <><div>
            <Routes>
                <Route exact path='/' Component={Home} />
                <Route exact path='/about' Component={About}/>
                <Route exact path='/contact' Component={Contact}/>
                <Route component={Error} />
            </Routes>
            </div>
            <div>
                <h1>Home Page</h1>
            </div>
        </>
    )
}
 export default Home;