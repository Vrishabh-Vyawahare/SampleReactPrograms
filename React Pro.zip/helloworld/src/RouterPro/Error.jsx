function Error() {
    return (
        <>
        <h1> Oops! Page not found</h1>
        </>
    )
}
export default Error;