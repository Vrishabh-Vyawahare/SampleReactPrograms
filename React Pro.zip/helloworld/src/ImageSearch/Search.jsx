import React,{useState} from 'react';
import Image from './Image'
const Search=()=>{

    const[imageName,setImageName]=useState('');

    const setInput=(e)=>{
        const data=e.target.value;
        setImageName(data);
    }

    return(
        <div>
        <input type="text" 
        value={imageName}
        placeholder='Enter image name'
        onChange={setInput}
        />
        <br />
        {imageName==='' ? null :<Image name={imageName}/> }
        </div>
    )
}
export default Search;

