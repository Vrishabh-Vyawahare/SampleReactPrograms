import React from 'react';



const Image=(props)=>{

    const img=`https://source.unsplash.com/400*300/?${props.name}`

    return(
        <div>
        <img src={img} alt="random image" />
        </div>
    )
}
export default Image;