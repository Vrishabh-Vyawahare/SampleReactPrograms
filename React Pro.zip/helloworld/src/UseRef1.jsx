import React,{ useRef} from 'react'

const UseRef=()=>{
    const InputRef= useRef(0);
 

    const HandleInput=()=>{
       InputRef.current.value='Vrishabh';
       InputRef.current.focus();
       InputRef.current.style.color='Red'
    }
    return(
        <>
        <input type='text' ref={InputRef} />
        <button onClick={HandleInput}>Click Me</button>
        </>
    )
}
export default UseRef;