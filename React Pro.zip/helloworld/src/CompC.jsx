import {firstname,lastname} from './CompA'
import {useContext} from 'react'

function CompC() {
    const fname=useContext(firstname);
    const lname=useContext(lastname);
    return (
    <h1>My name is {fname} {lname}</h1>
    );
  };
  
  export default CompC;