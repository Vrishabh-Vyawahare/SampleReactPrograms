import React,{useState} from 'react';

const Event=()=>{
    const newColor="grey";
    const[color,setColor]=useState(newColor);
    const[name,setName]=useState('Click Me');

    const updateColor=()=>{
        let newUpdatedColor="orange";
        setColor(newUpdatedColor);
        setName('Changed');
    }
    const Back=()=>{
        setColor(newColor);
        setName('Back');
    }
    return(
        <>
        <div style={{backgroundColor:color}}>
            <button onClick={updateColor} onDoubleClick={Back}>{name}</button>
        </div>
        </>

    )
}
export default Event;