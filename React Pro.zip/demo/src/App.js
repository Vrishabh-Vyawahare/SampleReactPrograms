import './App.css';
// import Navbar from './Component/Navbar';
import Combine from './HOC/Combine';

function App() {

  return (
    <div className="App">
      {/* <Navbar /> */}
      <Combine />
    </div>
  );
}

export default App;
