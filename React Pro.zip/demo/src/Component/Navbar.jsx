import './Navbar.css';
import { NavItem } from './NavItem';

function Navbar() {

  return (
    <nav className="Navbar">
        <h1 className="Navbar-logo">TravelFest</h1>
        <ul className="Navbar-menu">
            {NavItem.map((item,index)=>{
                return(
             <li>
                <a href={item.url}>
                <span>{item.icon}</span>
                 {item.title}
                </a>
             </li>
                )
            })}
           
        </ul>
        <button>Singup</button>
 
    </nav>
  );
}

export default Navbar;