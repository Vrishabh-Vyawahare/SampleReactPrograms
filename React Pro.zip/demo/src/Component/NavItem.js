import { FaHome,FaInfoCircle,FaServicestack,FaRegAddressCard} from 'react-icons/fa';
export const NavItem=[
    {
        title:'Home',
        icon:<FaHome/>,
        url:'/'
    },
    {
        title:'About',
        icon:<FaInfoCircle />,
        url:'/about'
    },
    {
        title:'Services',
        icon:<FaServicestack />,
        url:'/services'
    },
    {
        title:'Contact',
        icon:<FaRegAddressCard />,
        url:'/contact'
    }
]