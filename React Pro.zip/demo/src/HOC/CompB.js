import HOCComp from "./HOCComp";
function CompB(props) {
    const {Increment,count}=props;
    return (
      <div>
        <h1>{count}</h1>
        <button onClick={Increment}>INCREMENT</button>
      </div>
    );
  }
  
  export default HOCComp(CompB);