import {useState} from 'react'
function HOCComp(Wrapper) {
    function Counter(props){
        const[count,setCount]=useState(0);
        const Increment=()=>{
            setCount(count+1);
        }
        return(
            <div>
             <Wrapper Increment={Increment} count={count} {...props}/>
            </div>
        )
    }
    return Counter;
}
export default HOCComp;