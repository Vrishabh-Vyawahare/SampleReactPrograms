import HOCComp from "./HOCComp";
function CompA(props) {
    const {Increment,count,name}=props;
    return (
      <div>
        <h1>{count}</h1>
        <button onClick={Increment}>{name}</button>
      </div>
    );
  }
  
  export default HOCComp(CompA);