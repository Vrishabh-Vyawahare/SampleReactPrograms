import CompA from "./CompA";
import CompB from "./CompB";

function Combine() {
  return (
    <div>
     <CompA  name="john"/>
     <CompB />
    </div>
  );
}

export default Combine;