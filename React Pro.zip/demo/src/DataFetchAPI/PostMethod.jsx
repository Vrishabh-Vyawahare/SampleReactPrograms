import { useState,useEffect } from 'react'; 
function PostMethod() {
    const [data,setData]=useState({})
    const options={
        method: 'post',
        headers : {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
            },
        body: JSON.stringify( {
            "id": 2,
            "title": "IND",
            "author": "ROHIT"
        })

    }
    const fetchUser=()=>{
        fetch('http://localhost:3000/posts',options)
        .then((response)=>response.json())
        .then((result)=>setData(result))
    }
    useEffect(()=>fetchUser())

  return (
      <>
     <h1>POST Method Example</h1>
      </>
  );
}

export default PostMethod;