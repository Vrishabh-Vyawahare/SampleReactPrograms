import { useState,useEffect } from 'react'; 
function GetMethod() {
    const [data,setData]=useState([])
    
    const fetchUser=()=>{
        fetch(`https://jsonplaceholder.typicode.com/users`)
        .then((response)=>response.json())
        .then((result)=>setData(result))
    }
    useEffect(()=>fetchUser(),[])

  return (
      <>
     {
     data.map((value,index)=>{
       return(
         <div>
           <h1>{value.id}</h1>
          <h1>{value.name}</h1>
          <h1>{value.email}</h1>
         <h1>{value.username}</h1>

         </div>
        
       )
     }
    )
    }
      </>
  );
}

export default GetMethod;