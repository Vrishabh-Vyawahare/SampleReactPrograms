import { useState } from 'react'; 
import Axios from 'axios';
function PostAxios() {

    const [name,setName]=useState('');
    const [email,setEmail]=useState('');

    const nameHandler=(e)=>{
      setName(e.target.value);
      console.log(name);
    }
    const emailHandler=(e)=>{
        setEmail(e.target.value);
      }
    const submitHandler=(event)=>{
        event.preventDefault();
        const data={name,email};
        Axios.post('https://jsonplaceholder.typicode.com/posts',data)
       .then((response) =>console.log(response))
       .catch((error) => console.log(error))
    }

   return (   
    <div>
        <form>

            <label>firstname:</label>
            <input type="text" value={name} onChange={nameHandler}/>
        
            <br /><br />
            <label>email:</label>
            <input type="email"  value={email} onChange={emailHandler}/>

            <br /><br />
            <button type="submit" onClick={submitHandler}>Submit</button>

        </form>     
    </div>
  );
}

export default PostAxios;
