import { useState,useEffect } from 'react'; 
import Axios from 'axios';
function GetAxios() {
    const [data, setData] = useState([]);

    useEffect(() => {
      Axios.get('https://jsonplaceholder.typicode.com/users')
      .then((response) =>setData(response.data))
      .catch((error) => console.log(error))
    }, []);
  
  return (
      <>
      <h1>Axios Get Method</h1>
     {
     data.map((value,index)=>{
       return(
         <div>
           <h1>{value.id}</h1>
          <h1>{value.name}</h1>
          <h1>{value.email}</h1>
         <h1>{value.username}</h1>

         </div>
        
       )
     }
    )
    }
      </>
  );
}

export default GetAxios;