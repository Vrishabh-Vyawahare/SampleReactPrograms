import React from 'react';
import ReactDOM from 'react-dom/client';
// import Main from './CRUD/Main';
import PostAxios from './Axios/PostAxios';
// import GetAxios from './Axios/GetAxios';
// import PostMethod from './DataFetchAPI/PostMethod';
// import './index.css';
// import App from './App';
// import GetMethod from './DataFetchAPI/GetMethod';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <App /> */}
    {/* <GetMethod /> */}
    {/* <PostMethod /> */}
    {/* <GetAxios /> */}
    <PostAxios />
    {/* <Main /> */}
  </React.StrictMode>
);

