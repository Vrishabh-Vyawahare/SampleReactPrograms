import { BrowserRouter, Route, Routes } from 'react-router-dom';
import CreateData from './CreateData';
import ShowData from './ShowData';
import EditData from './EditData';

function Main() {
  return (
    <div>
      <BrowserRouter>
      <Routes>
        <Route  path="/" Component={ShowData}/>
        <Route exact path="/createdata" Component={CreateData}/>
        <Route  exact path="/editdata" Component={EditData}/>
      </Routes>
      </BrowserRouter>
    </div>
  );
}

export default Main;