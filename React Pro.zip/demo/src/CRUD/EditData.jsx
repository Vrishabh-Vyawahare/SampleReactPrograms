function EditData() {

  return (
    <div>
     <h1>EditData Page</h1>
    </div>
  );
}

export default EditData;