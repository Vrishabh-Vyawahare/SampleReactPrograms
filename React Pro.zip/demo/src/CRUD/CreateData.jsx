import {useState} from 'react';
import { Link, useNavigate} from 'react-router-dom';
import Axios from 'axios';

function CreateData() {
    const [name,setName]=useState('');
    const [team,setTeam]=useState('');
    const [jnum,setJnum]=useState('');

    const navigate = useNavigate();

    const nameHandler=(e)=>{
      setName(e.target.value);
    }
    const teamHandler=(e)=>{
        setTeam(e.target.value);
      }
      const jnumHandler=(e)=>{
        setJnum(e.target.value);
      }
      const submitHandler=(e)=>{
        e.preventDefault();
        const data={name,team,jnum};
        Axios.post(`https://jsonplaceholder.typicode.com/posts`,data)
       .then((response) =>{
           console.log(response);
           alert('data inserted sucussfully');
           navigate('/')})
       .catch((error) => console.log(error))
          
         }
      
return (
<div>
<form>

<label>Name Of Player:</label>
<input type="text" value={name} onChange={nameHandler}/>

<br /><br />
<label>Team:</label>
<input type="text"  value={team} onChange={teamHandler}/>

<br /><br />
<label>Jersy Number:</label>
<input type="number"  value={jnum} onChange={jnumHandler}/>

<br /><br />
<button type="submit" onClick={submitHandler}>SUBMIT</button>
<Link to='/'><button>BACK</button></Link>

</form>  
</div>
    );
  }
  
  export default CreateData;