import {useState,useEffect} from 'react';
import { Link } from 'react-router-dom';
function ShowData() {
    const [data,setData]=useState([]);
    useEffect(() => {
        fetch("http://localhost:3000/posts")
        .then((response)=>response.json())
        .then((result)=>setData(result))
      }, []);

    return (
      <div className="container">
          <div><h1>CRUD React JS</h1></div>
          <div><Link to='/createdata'><button>ADD USER</button></Link></div>
          <div>
              <table>
                  <thead>
                    <tr>
                        <th>Id</th>
                        <th>Name</th>
                        <th>Team</th>
                        <th>Jersy Number</th>
                        <th>Action</th>
                    </tr>
                  </thead>
                 <tbody>
                  {data.map((value,index)=>{
                      return(
                    <tr>
                        <td>{index+1}</td>
                        <td>{value.name}</td>
                        <td>{value.team}</td>
                        <td>{value.jnum}</td>
                        <td><button>Edit</button><button>Delete</button></td>
                    </tr>
                      )
                    
                  })}
                 
                 </tbody>  
                  
              </table>
          </div>
      </div>
    );
  }
  
  export default ShowData;